var oldAlarmSoundName = "";	//试听音响
var alarmVoiceFlag = false;       // 人声告警标志为,true表示开启
var audioObjs = {};	//音响信息
var ifRefAlarm = {};	//停止刷新标志
var ifLocalAlarm = false;	//本地标志
var ifFindAlarm = false;	//初始化查询标志
var currAudio = {};	//正在播放的音响
var clearObject = {};	//告警清除设置
var alarmCountObject = {};	//告警条数
var voiceLevObject = {};	//人声告警启用信息
var voiceInfo = [];	//人声告警列表
var utterThis = new window.SpeechSynthesisUtterance();
var isFloatLayerMoving = false;
var ifHideOverlimit = false;
var refAlarmObject = {};
var userStations = [];	//当前用户拥有的电站
var alarmViewIfAlart = false;	//是否自动弹窗
var alarmEnableFlag = {};	//声响禁用
var alarmIsPlaying = false;
var ifDisableAudio = false;
var newAlarmArray = new Array();

var typeAlarmWin = {
		0:'alarmViewBody',
		2:'telAlarmViewBody',
		7:'abnorAlarmViewBody',
		'-1':'overlimitViewBody',
		'-2':'soeViewBody'
};

var alarmTypeToLang = {
		'2': 'Msg.FM.displacementSignalTab',
		'7': 'Msg.FM.abnormalAlarmTab',
		'10': 'Msg.FM.protectionEventTab',
		'11': 'Msg.FM.communicationStateTab',
		'12': 'Msg.FM.informInformationTab'
};

var alarmTypeStrLang = {
		"保护事件": 'Msg.FM.protectionEventTab',
		"告知信息": 'Msg.FM.informInformationTab',
		"通信状态": 'Msg.FM.communicationStateTab'
};
var alarmTypeByNumber = {
		'Msg.FM.protectionEventTab': 10,
		'Msg.FM.informInformationTab': 12,
		'Msg.FM.communicationStateTab': 11,
		'Msg.FM.overLimitTab': -1,
		'SOE': -2,
		'Msg.FM.alarmOverviewTab': 0,
		'Msg.FM.abnormalAlarmTab': 7,
		'Msg.FM.displacementSignalTab': 2
};
var alarmBtnTypeByLang = {
		'2': {'btn1': 'Msg.FM.confirmDisplacementSignal', 'btn2': 'Msg.FM.clearDisplacementSignal'},
		'7': {'btn1': 'Msg.FM.confirmAlarm', 'btn2': 'Msg.FM.clearAlarm'},
		'10': {'btn1': 'Msg.FM.confirmProtectEvent', 'btn2': 'Msg.FM.clearProtectEvent'},
		'11': {'btn1': 'Msg.FM.confirmCommunicatState', 'btn2': 'Msg.FM.clearCommunicatState'},
		'12': {'btn1': 'Msg.FM.confirmInformInformation', 'btn2': 'Msg.FM.clearInformInformation'},
		'-1': {'btn1': 'Msg.overLimitAlarm.confirm', 'btn2': 'Msg.overLimitAlarm.clear'},
		'-2': {'btn1': 'Msg.FM.confirmSoe', 'btn2': 'Msg.FM.clearSoe'}
};
var defAlarmView = ['Msg.FM.overLimitTab', 'SOE'];
var allAlarmView = ['Msg.FM.alarmOverviewTab', 'Msg.FM.abnormalAlarmTab', 'Msg.FM.displacementSignalTab'];

var comcAlarmTypeToNumber = {
		'变位信号': 2,
		'异常告警': 7,
		'保护事件': 10,
		'通信状态': 11,
		'告知信息': 12
}

var alarmViewIfOpen = false;

var addAlarmFloat = function(e){
	if(e.operationData){
		// 用户没有电站权限，不展示告警
		if(e.operationData.stationCode && userStations.indexOf(e.operationData.stationCode) < 0){
			return;
		}
	}
	
	var referer = parent.Cookies.get("Referer");
	var runMode = parent.Cookies.get('ComcMode');
	
	if(referer && referer == 'COMC' && !(runMode && runMode == "COMC")){
		if('SSOCOMCAlarm' == e.operation){
			if(e.operationData.ifSoe && e.operationData.ifSoe == 1){
				e.operation = 'newSoe';
			} else{
				e.operation = 'newDisplacementSignal';
			}
		} else if('SSOCOMCOverlimit' == e.operation){
			onNewOverLimitMsg(e);
		} else{
			//集控跳转，非集控推送告警，都屏蔽掉
			return;
		}
	}
	
	if(loadOldAlarm){
		newAlarmArray.push(e);
		return;
	}
	
	if(e.operation == "newSoe"){
		var dataOption = '';
    	if('ACTIVE' == e.operationData.status){
    		dataOption = 'add';
    	} else if('ACKNOWLEDGEMENT' == e.operationData.status){
    		dataOption = 'update';
    	} else{
    		if(clearObject[e.operationData.severityId] && !e.operationData.ackDate){
    			dataOption = 'update';
    		} else{
    			dataOption = 'delete';
    		}
    	}
    	if(ifRefAlarm[-2]){
    		if(!refAlarmObject['-2']){
    			refAlarmObject['-2'] = [];
    		}
    		refAlarmObject['-2'].push({'dataOption': dataOption, 'operationData': e.operationData});
    		return;
    	}
    	$('#'+typeAlarmWin['-2']).alarmTable(dataOption, e.operationData);
		return;
	}
	if(e.operation != "newDisplacementSignal" && e.operation != 'newAlarm'){
		return;
	}
	
	var alarmType = e.operationData.alarmType;
	if(comcAlarmTypeToNumber[alarmType]){
		alarmType = comcAlarmTypeToNumber[alarmType];
		e.operationData.alarmType = alarmType;
	}
	if(!e.operationData.name){
		e.operationData.name = e.operationData.alarmName;
	}
	var winId = typeAlarmWin[alarmType];
	if(!winId){
		winId = 'testAlarmWin';
	}
	var dataOption = '';
	var showAlarmWindClick = false;
	if('ACTIVE' == e.operationData.status){
		showAlarmWindClick = true;
		dataOption = 'add';
	} 
	else{
		var lev = e.operationData.severityId;
		if(!lev){
			lev = e.operationData.alarmLevel;
		}
		if((clearObject[lev] && !e.operationData.ackDate) || 'ACKNOWLEDGEMENT' == e.operationData.status){
			showAlarmWindClick = true;
			dataOption = 'update';
		} else{
			dataOption = 'delete';
		}
	}
	if(!alarmViewIfOpen && alarmViewIfAlart && showAlarmWindClick){
		$('.alarmWinBtn[alarmType='+alarmType+']').click();
		ifFindAlarm = true;
	}
	var refAudio = true;
	var count = 2;
	if(ifRefAlarm[alarmType]){
		refAudio = false;
		if(!refAlarmObject[alarmType]){
			refAlarmObject[alarmType] = [];
		}
		refAlarmObject[alarmType].push({'dataOption': dataOption, 'operationData': e.operationData});
		count--;
	}
	if(refAudio){
		$('#'+winId).alarmTable(dataOption, e.operationData);
	}
	if(ifRefAlarm['0']){
		refAudio = false;
		if(!refAlarmObject['0']){
			refAlarmObject['0'] = [];
		}
		refAlarmObject['0'].push({'dataOption': dataOption, 'operationData': e.operationData});
		count--;
	}
	if(refAudio){
		$('#'+typeAlarmWin['0']).alarmTable(dataOption, e.operationData);
	}
	if(count != 0){
		if(e.operationData.status == "ACTIVE"){
			setAlarmAudio(e.operationData);
		} else{
			if(currAudio[e.operationData.id]){
				delete currAudio[e.operationData.id];
				var mAudio = document.getElementById("main_au");
				mAudio.pause();
			}
		}
	}
}

function initSpeck(){
	utterThis.lang = 'zh';
	utterThis.rate = 0.7;
	utterThis.pitch = 1.2;
}

$(function (){
	initSpeck();
	
	var referer = parent.Cookies.get("Referer");
    var runMode = parent.Cookies.get('ComcMode');
	if((runMode && runMode == "COMC") || (referer && referer == 'COMC')){
		ifLocalAlarm = false;
    } else {
    	ifLocalAlarm = true;
    	$.omcAjax('/alarmType/getHiddenTypeAlarmNums',{},function(res){
    		var data = res.data;
    		overLimitFlag = data.operationAndMaintenance;
    		if(overLimitFlag == 0){
    			ifHideOverlimit = true;
    			defAlarmView.splice(defAlarmView.indexOf('Msg.FM.overLimitTab'), 1);
    		} else{
    			ifHideOverlimit = false;
    		}
    	}, false);
    }
	
	_iframeMouseMove = function (e) {
		if(isFloatLayerMoving){
			var disY = e.clientY;
			var maxHeight = window.innerHeight;
			var top = disY -30;
			if(maxHeight - disY < 55){
				top = maxHeight - 85;
			}
			if(top < 30){
				top = 30;
			}
			$('.alarmAlertWin').css('bottom,', '30px');
			var height = maxHeight-disY-10;
			$('.alarmAlertWin').css('height', height+'px');
			for(var type in typeAlarmWin){
				var winId = typeAlarmWin[type];
				$("#"+winId).alarmTable('updateHeight', height-38);
			}
	  	}
	};
	$(document).on('mousemove', _iframeMouseMove)
	.on('mouseup', function (e) {
		isFloatLayerMoving = false;
		console.log('document mouseup: ' + isFloatLayerMoving);
	});
	
	//获取常规设置
	getActiveMaxNum(true);
	//获取告警颜色
	findAlarmColorInfo(false);
	//获取声响设置
	findAlarmSoundInfo();
	//获取告警清除设置
	getAlarmClearSet();
	//获取声响禁用设置
	findAlarmEnabledInfo();
	getAlarmViewTable();
	findAlarmInfo('station');
	window.parent.Webchannel.regBusitype("fmWebSocketService", listenerFmSocket);
    window.parent.Webchannel.startPush("fmWebSocketService", "123");
});

function newAlarmInfo(type, e){
	var winId = typeAlarmWin[type];
	if(!winId){
		return;
	}
	var dataOption = '';
	if('ACTIVE' == e.operationData.status){
		dataOption = 'add';
	}else{
		dataOption = 'delete';
	}
	$('#'+winId).alarmTable(dataOption, e.operationData);
}

function showAlarmWindow(){
	$('.alarmAlertWin').show();
}

function hideAlarmWindow(){
	$('.alarmAlertWin').hide();
}

function getAlarmViewTable(){
	if(!ifLocalAlarm){
		typeAlarmWin[10] = 'protectionViewBody';
		typeAlarmWin[11] = 'communicationViewBody';
		typeAlarmWin[12] = 'informInformationViewBody';
		defAlarmView.unshift(alarmTypeStrLang['保护事件']);
		defAlarmView.unshift(alarmTypeStrLang['告知信息']);
		defAlarmView.unshift(alarmTypeStrLang['通信状态']);
		defAlarmView.map(function (e){
			if('Msg.FM.protectionEventTab' == e){
				allAlarmView.splice(1, 0, e);
			} else{
				allAlarmView.push(e);
			}
    	});
    	initAlarmWin();
		return;
	}
    $.omcAjax("/fmFloat/getAlarmViewTable", {}, function (res) {
    	if(res.data){
    		res.data.map(function (e){
    			defAlarmView.unshift(alarmTypeStrLang[e]);
    			if(e == '保护事件'){
    				typeAlarmWin[10] = 'protectionViewBody';
    			} else if(e == '告知信息'){
    				typeAlarmWin[12] = 'informInformationViewBody';
    			} else if(e == '通信状态'){
    				typeAlarmWin[11] = 'communicationViewBody';
    			}
        	});
    	}
    	defAlarmView.map(function (e){
    		if('Msg.FM.protectionEventTab' == e){
				allAlarmView.splice(1, 0, e);
			} else{
				allAlarmView.push(e);
			}
    	});
    	initAlarmWin();
    });
}

var onNewOverLimitMsg = function (e){
	
	var referer = parent.Cookies.get("Referer");
	var runMode = parent.Cookies.get('ComcMode');
	if(referer && referer == 'COMC' && !(runMode && runMode == "COMC")){
		if('SSOCOMCOverlimit' == e.operation){
			e.operation = "newOverLimit";
		} else{
			//集控跳转，非集控推送告警，都屏蔽掉
			return;
		}
	}
	
	if(e.operationData){
		// 用户没有电站权限，不展示告警
		if(e.operationData.stationCode && userStations.indexOf(e.operationData.stationCode) < 0){
			return;
		}
	}
	
	var operation = e.operation;
	if (operation == "newOverLimit") {
		var dataOption = '';
		var showAlarmWindClick = false;
    	if('ACTIVE' == e.operationData.status){
    		dataOption = 'add';
    		showAlarmWindClick = true;
    	} else if('ACKNOWLEDGEMENT' == e.operationData.status){
    		dataOption = 'update';
    	} else{
    		dataOption = 'delete';
    	}
    	
    	if(!alarmViewIfOpen && alarmViewIfAlart && showAlarmWindClick){
			ifFindAlarm = true;
    		$('.alarmWinBtn[alarmType=-1]').click();
    	}
    	
    	var alarmType = '-1';
    	if(ifRefAlarm[alarmType]){
    		if(!refAlarmObject[alarmType]){
    			refAlarmObject[alarmType] = [];
    		}
    		refAlarmObject[alarmType].push({'dataOption': dataOption, 'operationData': e.operationData});
    		return;
    	}
    	$('#'+typeAlarmWin[alarmType]).alarmTable(dataOption, e.operationData);
    	e.operationData.alarmType = 14;
		if(e.operationData.status == "ACTIVE"){
			setAlarmAudio(e.operationData);
		} else{
			if(currAudio[e.operationData.id]){
				delete currAudio[e.operationData.id];
				var mAudio = document.getElementById("main_au");
				mAudio.pause();
			}
		}
	}
}

function initAlarmWin(){
	window.parent.Webchannel.regBusitype("telesignalWebSocketCmp", addAlarmFloat);
    window.parent.Webchannel.startPush("telesignalWebSocketCmp", "222");
    
    window.parent.Webchannel.regBusitype("overLimitWebsocketService", onNewOverLimitMsg);
    window.parent.Webchannel.startPush("overLimitWebsocketService", "1");
    
	setAlarmWin();
}

function speakNext(){
	if(voiceInfo.length > 0){
		var str = voiceInfo.shift();
		utterThis.text = str;
		utterThis.onend = function() {
            speakNext();
        };
        window.speechSynthesis.speak(utterThis);
	} else{
		alarmIsPlaying = false;
	}
}

function setAlarmAudio(data){
	//禁止音响
	if(ifDisableAudio){
		return;
	}
	if(0 == alarmEnableFlag[data.alarmType]){
		return;
	}
	var lev = data.severityId;
	if(!lev){
		lev = data.alarmLevel;
	}
	//人声告警
	if(alarmVoiceFlag && voiceLevObject[lev] && voiceLevObject[lev] == 1){
		var str = data.ttsStr;
		var devNameDecode = toHexTostr(data.devName);
		if(!str){
			if(data.belongInterval){
				str = data.stationName + "。" + data.belongInterval + "。" + devNameDecode + "。" + data.name;
			} else{
				str = data.stationName + "。" + data.alarmInterval + "。" + devNameDecode + "。" + data.name;
			}
			data.ttsStr = str;
		}
		str = str.replace(/[-]/g,"。");
		str = str.replace(/((\d+(\.\d+)?)[Ee]{1}(\d+))/g, function(str){
			return str.replace(/./g, " $& ");
		});
		voiceInfo.push(str);
		if(!alarmIsPlaying){
			speakNext();
			alarmIsPlaying = true;
		}
		return;
	}
	if(alarmVoiceFlag){
		return;
	}
	var mAudio = document.getElementById("main_au");
	var fileName = audioObjs[lev+""+data.alarmType];
	var ifAudio = false;
	var num = 0;
	for(var i in currAudio){
		num++;
		if(currAudio[i] != fileName){
			ifAudio = true;
		}
	}
	if(0 == num){
		ifAudio = true;
	}
	currAudio = {};
	currAudio[data.id] = fileName;
	if(ifAudio){
		mAudio.src = "/module/fm/music/" + fileName;
		mAudio.play();
	}
}

function setAlarmWin(){
	$('.alarmAlertWin').remove();
	var alertWin = "<div class='alarmAlertWin'>" + "<div class='alarmWinTitleBottom'>" + "<div class='showWinTitle'>";
	var alertWinView = "";
	var clickWinView = "";
	allAlarmView.map(function (e){
		var text = e;
		if(e != 'SOE'){
			text = eval(e);
		}
		alertWinView += "<div class='alarmWinBtn2 text' language='"+e+"' alarmType='"+alarmTypeByNumber[e]+"' onclick='showAlarmWin(this)'>"+text+"</div>";
		clickWinView += "<div class='alarmWinBtn text' language='"+e+"' alarmType='"+alarmTypeByNumber[e]+"' onclick='showAlarmWin(this)'>"+text+"</div>";
	});
	alertWinView += "</div><div class='closeWinTitle'>"+clickWinView +
				"</div>" +
				"</div>" +
				"<div class='alarmWinLine'></div> <div style='background: black;'>" +
				"<div class='alarmWinButtons'>" +
					"<div class='alarmOverviewClass'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title' value='设置' language='Msg.set' languagetitle='Msg.FM.alarmSetting' onclick='alarmBtnSetting()'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title imageAlarmBtn' value='停止音响' language='Msg.FM.stopAudio' languagetitle='Msg.FM.stopAudio' onclick='alarmStopAudio()'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title' value='过滤屏蔽' language='Msg.FM.filter' languagetitle='Msg.FM.filter' onclick='popAlarmFilter()'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title' value='暂停刷新' language='Msg.overLimitAlarm.stopRefresh' languagetitle='Msg.overLimitAlarm.stopRefresh' id='refBtn0' alarmType='0' onclick='stopRefreshBtn(this)'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title imageAlarmBtn' value='禁用音响' language='Msg.FM.forbiddenAudio' languagetitle='Msg.FM.forbiddenAudio' onclick='disableAudio(this)' style='display: none;'>" +
					"</div>" +
					"<div class='alarmOverviewOther'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn7' alarmType='7' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn2' alarmType='2' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn11' alarmType='11' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn12' alarmType='12' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn10' alarmType='10' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn-1' alarmType='-1' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn' id='refBtn-2' alarmType='-2' onclick='stopRefreshBtn(this)' hidden='true' value='暂停刷新' language='Msg.FM.stopRefresh' languagetitle='Msg.FM.stopRefresh'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn1' onclick='otherViewBtn1()'>" +
						"<input type='button' class='alarmFloatfont-buttonbg textValue il8n-title otherViewBtn2' onclick='otherViewBtn2()'>" +
					"</div>" +
					"<div class='alarmCountClass'>" +
						"<div>" +
							"<span class='text il8n-title' language='Msg.FM.total' languagetitle='Msg.FM.total'>"+Msg.FM.total+"</span>" +
							"<span class='overviewTotalNum'>0</span>" +
						"</div>" +
						"<div>" +
							"<span class='text il8n-title' language='Msg.FM.confirmedAlarm' languagetitle='Msg.FM.confirmedAlarm'>"+Msg.FM.confirmedAlarm+"</span>" +
							"<span class='overviewConfirmedNum'>0</span>" +
						"</div>" +
						"<div>" +
							"<span class='text il8n-title' language='Msg.FM.unConfirmedAlarm' languagetitle='Msg.FM.unConfirmedAlarm'>"+Msg.FM.unConfirmedAlarm+"</span>" +
							"<span class='overviewUnConfirmedNum'>0</span>" +
						"</div>" +
					"</div>" +
				"</div>" +
				"<div class='alarmViewBody classHideDiv' id='alarmViewBody'></div>" +
				"<div class='telAlarmViewBody classHideDiv' id='telAlarmViewBody'></div>" +
				"<div class='abnorAlarmViewBody classHideDiv' id='abnorAlarmViewBody'></div>" +
				"<div class='protectionViewBody classHideDiv' id='protectionViewBody'></div>" +
				"<div class='communicationViewBody classHideDiv' id='communicationViewBody'></div>" +
				"<div class='informInformationViewBody classHideDiv' id='informInformationViewBody'></div>" +
				"<div class='overlimitViewBody classHideDiv' id='overlimitViewBody'></div>" +
				"<div class='soeViewBody classHideDiv' id='soeViewBody'></div>" +
			"</div></div>";
	$('body').append(alertWin + alertWinView);
	$('.showWinTitle div').hide();
	showAlarmViewBody();
	var winId = typeAlarmWin['2'];
	$("#"+winId).alarmTable('updateHeight', '210');
	var winWidth = 830;
	if(parent.Cookies.get("typeValGlob") == 'zh'){
		winWidth = 485;
	}
	var setObj = {
			position:{at:"center"},
			autoOpen: false,
			resizable:false,
			closeText:Msg.close,
			width: winWidth,
			height:300,
			title:'Msg.FM.overviewSetting',
			modal: true,
			buttons:{},
			close:function(){
				var optobj = $(this).dialog("option","position");
				optobj.my = "center";
				optobj.at = "center",
				$(this).dialog("option","position",optobj);
			}
	};
	var buttonok = 'Msg.FM.save';
	var buttoncancel = 'Msg.FM.recover';
	setObj.buttons[buttonok] = function(){
		//保存
		var showDivid = $('.selectDivClass').attr('showdivid');
		clickBtnFunction(showDivid, 'save');
	}
	setObj.buttons[buttoncancel] = function(){
		//恢复默认
		var showDivid = $('.selectDivClass').attr('showdivid');
		clickBtnFunction(showDivid, 'rev');
	}
	$("#alarmSettingWin").globleDialog(setObj);
	
	initPopAlarmFilterWin();
	
	if(ifLocalAlarm){
		hideAlarmWindow();
    }
	
	setsuggestionWin();
	$('.alarmAlertWin').css('height', '0');
	$('.alarmAlertWin').css('bottom', '30px');
}

function setsuggestionWin(){
	var setObj = {
			position:{at:"center"},
			autoOpen: false,
			resizable:false,
			closeText:Msg.close,
			width: 660,
			height: 530,
			title:'Msg.FM.repairSuggestion',
			modal: true,
			buttons:{},
			close:function(){
				var optobj = $(this).dialog("option","position");
				optobj.my = "center";
				optobj.at = "center",
				$(this).dialog("option", "position", optobj);
			}
	};
	var buttonok = 'Msg.close';
	setObj.buttons[buttonok] = function(){
		//关闭
		$("#showSuggestionWin").globleDialog('close');
	}
	$("#showSuggestionWin").globleDialog(setObj);
}

function clickBtnFunction(showDivid, option){
	switch (showDivid) {
		case 'colorSetDiv':
			if(option == 'save'){
				saveAlarmColorSet();
			} else{
				recoverAlarmColor();
			}
			break;
		case 'soundSetDiv':
			if(option == 'save'){
				saveAlarmSound();
			} else{
				recoverAlarmSound();
			}
			break;
		case 'enabledSetDiv':
			if(option == 'save'){
				saveAlarmEnable();
			} else{
				recoverAlarmEnable();
			}
			break;
		case 'clearSettingDiv':
			if(option == 'save'){
				saveAlarmClear();
			} else{
				recoverAlarmClear();
			}
			break;
		default:
			if(option == 'save'){
				recoverAlarmCommonSave();
			} else{
				recoverAlarmCommonSetting();
			}
			break;
	}
}

//保存告警清除设置
function saveAlarmClear(){
	var inputs = $('.alarmClearSetDiv input');
	var clearObj = {};
	inputs.map(function (e){
		var lev = 1;
		if('importantBox' == inputs[e].id){
			lev = 1;
		} else if('secondaryBox' == inputs[e].id){
			lev = 2;
		} else{
			lev = 3;
		}
		clearObj[lev] = inputs[e].checked == true ? 1:0;
	});
	$.omcAjax("/fmFloat/saveAlarmClear", {
		"clearObj": clearObj
	}, function (res) {
		if(res.success){
			clearObject = clearObj;
			findAlarmInfo(0);
			parent.App.myMsg(Msg.FM.saveFilter);
		} else{
			parent.App.myMsg(Msg.saveFail);
		}
    });
}

function getStrAlarmEnabType(id){
	var typeId = '';
	if('emabledprotectionEvent' == id){
		typeId = 'protectionEvent';
	} else if('emabledabnormalAlarm' == id){
		typeId = 'abnormalAlarm';
	} else if('emableddisplacementSignal' == id){
		typeId = 'displacementSignal';
	} else if('emabledcommunicationState' == id){
		typeId = 'communicationState';
	} else if('emabledinformInformation' == id){
		typeId = 'informInformation';
	} else if('emabledoverLimit' == id){
		typeId = 'overLimit';
	} else{
		typeId = id;
	}
	return typeId;
}

//保存声响禁用设置
function saveAlarmEnable(){
	var inputs = $('#enabledSetDiv input');
	var enable = {};
	inputs.map(function (e){
		var id = getStrAlarmEnabType(inputs[e].id);
		var val = $(inputs[e]).attr('emableVal');
		enable[id] = val;
		setAlarmTypeByObj(id, val);
	});
	$.omcAjax("/fmFloat/saveAlarmEnable", {
		"enable": enable
	}, function (res) {
		if(res.success){
			parent.App.myMsg(Msg.FM.saveFilter);
		} else{
			parent.App.myMsg(Msg.saveFail);
		}
    });
}

//保存声响设置
function saveAlarmSound(){
	var soundObj = {};
	var soundType = 1;
	if(!alarmVoiceFlag){//非人声
		var selects = $('#soundSetDiv select');
		selects.map(function (e){
			var selId = selects[e].id;
			var val = $(selects[e]).val();
			soundObj[selId.split('soundBtnLevel')[1]] = val;
		});
		
	} else{
		var inps = $('.alarmSoundSetDiv input');
		inps.map(function (e){
			var selId = inps[e].id;
			soundObj[selId.split('voiceSound')[1]] = $(inps[e]).attr('enabled');
			voiceLevObject[selId.split('voiceSound')[1]] = $(inps[e]).attr('enabled');
		});
		soundType = 2;
	}
	$.omcAjax("/fmFloat/saveAlarmSound", {
		"soundObj": soundObj,
		"soundType": soundType
	}, function (res) {
		if(res.success){
			parent.App.myMsg(Msg.FM.saveFilter);
		} else{
			parent.App.myMsg(Msg.saveFail);
		}
    });
}

function alarmSoundBtn(e){
	var emableVal = $(e).attr('enabled');
	if('0' == emableVal){
		$(e).val(Msg.FM.stopUse);
		$(e).attr('enabled', 1);
	} else{
		$(e).val(Msg.FM.startUse);
		$(e).attr('enabled', 0);
	}
}

//告警颜色设置
function saveAlarmColorSet(){
	var colorInput = $("#colorSetDiv input");
	var colors = [];
	colorInput.map(function (e){
		var alarmType = $(colorInput[e]).attr('alarmType');
		var alarmLev = $(colorInput[e]).attr('alarmLev');
		var buttonColor = $(colorInput[e]).attr('buttonColor');
		if(buttonColor.indexOf('#') == 0){
			buttonColor = buttonColor.substring(1, buttonColor.length);
		}
		var colorObj = {};
		colorObj.alarmType = alarmType;
		colorObj.perceivedSeverity = alarmLev;
		colorObj.colorValue = buttonColor;
		colors.push(colorObj);
	});
	
	$.omcAjax("/fmFloat/saveAlarmColor", {
		"colors": colors
	}, function (res) {
		if(res.success){
			parent.App.myMsg(Msg.FM.saveFilter);
			findAlarmInfo(0);
		} else{
			parent.App.myMsg(Msg.saveFail);
		}
    });
}

function recoverAlarmCommonSave(){
	var settingCommonData = {};
	settingCommonData.maxActivedNum = $('#activitedAlarmMaxNum').val();
	var isActiveWindow = $('input[name=activeAlarmWindow]:checked').val();
	if('1' == isActiveWindow){
		isActiveWindow = true;
	} else{
		isActiveWindow = false;
	}
	alarmViewIfAlart = true;
	settingCommonData.isActiveWindow = isActiveWindow;
	$.omcAjax("/fmFloat/saveAlarmCommon", {
		"configIndex": 1,
		"postData": settingCommonData
	}, function (res) {
		if(res.success){
			parent.App.myMsg(Msg.FM.saveFilter);
			findAlarmInfo(0);
		} else{
			parent.App.myMsg(Msg.saveFail);
		}
    });
}

function initPopAlarmFilterWin(){
	var winWidth = 685;
	if(parent.Cookies.get("typeValGlob") == 'zh'){
		winWidth = 460;
	}
	var setObj = {
			position:{at:"center"},
			autoOpen: false,
			resizable:false,
			closeText:Msg.close,
			width: winWidth,
			height:320,
			title:'Msg.FM.overviewSetting',
			modal: true,
			buttons:{},
			close:function(){
				var optobj = $(this).dialog("option","position");
				optobj.my = "center";
				optobj.at = "center",
				$(this).dialog("option","position",optobj);
			}
	};
	var buttonok = 'Msg.FM.save';
	var buttoncancel = 'Msg.FM.recover';
	setObj.buttons[buttonok] = function(){
		//保存
		var objs = {};
		//获取界面勾选的数据
		var levCheck = $('.alarmLevFilter:checked');
		if(levCheck.length > 0){
			var levs = [];
			levCheck.map(function (e){
				var id = levCheck[e].id;
				levs.push(id.charAt(id.length-1));
			});
			objs.levs = levs;
		}
		var typeCheck = $('.alarmTypeFilter:checked');
		if(typeCheck.length > 0){
			var types = [];
			typeCheck.map(function (e){
				var id = typeCheck[e].id;
				if('alarmType1' == id){
					types.push('保护事件');
				} else if('alarmType2' == id){
					types.push('异常告警');
				} else if('alarmType3' == id){
					types.push('变位信号');
				} else if('alarmType4' == id){
					types.push('通信状态');
				} else if('alarmType5' == id){
					types.push('告知信息');
				}
			});
			objs.types = types;
		}
		$.omcAjax("/fmFloat/filter", {"objs": objs}, function (res) {
			if(res.success){
				parent.App.myMsg(Msg.FM.saveFilter);
			} else{
				parent.App.myMsg(Msg.saveFail);
			}
	    });
	}
	setObj.buttons[buttoncancel] = function(){
		$.omcAjax("/fmFloat/recoverFilter", {}, function (res) {
			if(res.success){
				//恢复默认
				parent.App.myMsg(Msg.FM.recoverFilter);
			} else{
				parent.App.myMsg(Msg.rwmenu.centralized.timeoutAlarm.restFail);
			}
	    });
	}
	$("#popAlarmFilterWin").globleDialog(setObj);
}

function stopRefreshBtn(e){
	$(e).prop("disabled", true);
	ifRefAlarm[$(e).attr('alarmType')] = true;
	var counter = 15;
	if(parent.Cookies.get('typeValGlob').indexOf("en") >= 0){
    	$(e).val(Msg.FM.beforeRefresh + (counter--) + "s");
    }else{
    	$(e).val((counter--) + Msg.FM.beforeRefresh);
    }
	$(e).everyTime('1s', function(){
    	if(parent.Cookies.get('typeValGlob').indexOf("en") >= 0){
    		$(e).val(Msg.FM.beforeRefresh + (counter--) + "s");
    	}else{
    		$(e).val((counter--) + Msg.FM.beforeRefresh);
    	}
    }).oneTime('15s', function(){
        $(e).val(Msg.FM.stopRefresh).stopTime();
        $(e).prop("disabled", false);
        var type = $(e).attr('alarmType');
        ifRefAlarm[type] = false;
        var alarms = refAlarmObject[type];
        if(alarms){
        	delete refAlarmObject[type];
            for(var i=0; i<alarms.length; i++){
            	refAlarmTime(type, alarms[i]);
            }
        }
    });
}

function refAlarmTime(type, e){
	$('#'+typeAlarmWin[type]).alarmTable(e.dataOption, e.operationData);
}

//告警清除恢复默认
function recoverAlarmClear(){
	$.omcAjax("/fmFloat/recoverAlarmClear", {"configIndex": 1}, function (res) {
		if(res.success){
			findAlarmInfo(0);
			parent.App.myMsg(Msg.FM.recoverFilter);
			$('.alarmClearSetDiv input').prop('checked', false);
			for(var i in clearObject){
				clearObject[i] = 0;
			}
		} else{
			parent.App.myMsg(Msg.rwmenu.centralized.timeoutAlarm.restFail);
		}
    });
}

//声响禁用恢复默认
function recoverAlarmEnable(){
	$.omcAjax("/fmFloat/recoverEnableSet", {}, function (res) {
		if(res.success){
			parent.App.myMsg(Msg.FM.recoverFilter);
			var inputs = $('#enabledSetDiv input');
			inputs.map(function (e){
				$(inputs[e]).val(Msg.FM.stopUse);
				$(inputs[e]).attr('emableVal', 1);
				setAlarmTypeByObj(getStrAlarmEnabType($(inputs[e])[0].id), 1);
			});
		} else{
			parent.App.myMsg(Msg.rwmenu.centralized.timeoutAlarm.restFail);
		}
    });
}

//声响设置恢复默认
function recoverAlarmSound(){
	var soundType = 1; //普通声响
	if(alarmVoiceFlag){
		soundType = 2;
	}
	$.omcAjax("/fmFloat/recoverAlarmSound", {"soundType": soundType}, function (res) {
		if(res.success){
			findAlarmSoundInfo();
			parent.App.myMsg(Msg.FM.recoverFilter);
		} else{
			parent.App.myMsg(Msg.rwmenu.centralized.timeoutAlarm.restFail);
		}
    });
}

//颜色设置恢复默认
function recoverAlarmColor(){
	$.omcAjax("/fmFloat/recoverColor.do", {"configIndex": 1}, function (res) {
		if(res.success){
			parent.App.myMsg(Msg.FM.recoverFilter);
			findAlarmInfo(0);
		} else{
			parent.App.myMsg(Msg.rwmenu.centralized.timeoutAlarm.restFail);
		}
    });
}

//常规设置恢复默认
function recoverAlarmCommonSetting(){
	$.omcAjax("/fmFloat/recoverCommon", {"configIndex": 1}, function (res) {
		if(res.success){
			setCommonInfo();
			parent.App.myMsg(Msg.FM.recoverFilter);
		} else{
			parent.App.myMsg(Msg.rwmenu.centralized.timeoutAlarm.restFail);
		}
    });
}

function setCommonInfo(){
	$('input[name=activeAlarmWindow]')[0].checked = true;
	$('input[name=activeAlarmWindow]')[1].checked = false;
	alarmViewIfAlart = true;
	$('#activitedAlarmMaxNum').val(200);
	findAlarmInfo(0);
}

function stopAlarmVoice(){
	voiceInfo = [];
	speechSynthesis.cancel();
	alarmIsPlaying = false;
}

//停止音响
function alarmStopAudio(){
	var mAudio = document.getElementById("main_au");
    if(alarmVoiceFlag){
    	stopAlarmVoice();
    }else{
    	mAudio.pause();
    	currAudio = {};
    	$.omcAjax("/fmFloat/stopAudio", {}, function (res) {});
    }
}

var showAlarmViewBody = function (){
	//告警总览
	var overviewObj = {
			height: 500,
			page: false,
			limit: 200,
			cols: [
			    {field: 'id', title: 'Msg.FM.IDTable', sort: true, align: 'center', width: '4'},
				{field: 'severityId', title: 'Msg.FM.PERCEIVEDSEVERITYNO', sort: true, align: 'center', width: '4', exFun:'getSeverityId'},
				{field: 'status', title: 'Msg.FM.ALARM_STATUSNO', sort: true, align: 'center', width: '4', exFun:'getIfstatus'},
				{field: 'name', title: 'Msg.FM.ALARM_NAMENO', sort: true, align: 'center', width: '20'},
				{field: 'raisedDate', title: 'Msg.FM.AISE_DATE', sort: true, align: 'center', width: '10', exFun:'getRaisedDate'},
				{field: 'recoverDate', title: 'Msg.FM.ALARM_ACT_TIME', sort: true, align: 'center', width: '10', exFun:'getRecoverDate'},
				{field: 'stationName', title: 'Msg.FM.BELONGED_FACTORYNO', sort: true, align: 'center', width: '16'},
				{field: 'alarmInterval', title: 'Msg.FM.ALARM_INTERVALNO', sort: true, align: 'center', width: '10'},
				{field: 'devName', title: 'Msg.FM.ALARM_DEVNO', sort: true, align: 'center', width: '10', exFun:'setAlarmDevName'},
				{field: 'alarmType', title: 'Msg.FM.ALARM_TYPENO', sort: true, align: 'center', width: '5', exFun:'setAlarmTypeFun'},
				{field: 'suggestion', title: 'Msg.FM.ALARM_SUGGESTION', sort: true, align: 'center', exFun:'setSuggestionFun'}
			],
			countFunction: 'setAlarmCount',
			checked: true
	};
	
	$('.'+typeAlarmWin[0]).alarmTable(overviewObj);
	
	var objs = {
			height: 500,
			page: false,
			limit: 200,
			cols: [
			    {field: 'id', title: 'Msg.FM.IDTable', sort: true, align: 'center', width: '4'},
				{field: 'severityId', title: 'Msg.FM.PERCEIVEDSEVERITYNO', sort: true, align: 'center', width: '4', exFun:'getSeverityId'},
				{field: 'status', title: 'Msg.FM.ALARM_STATUSNO', sort: true, align: 'center', width: '4', exFun:'getIfstatus'},
				{field: 'name', title: 'Msg.FM.ALARM_NAMENO', sort: true, align: 'center', width: '22'},
				{field: 'raisedDate', title: 'Msg.FM.AISE_DATE', sort: true, align: 'center', width: '10', exFun:'getRaisedDate'},
				{field: 'recoverDate', title: 'Msg.FM.ALARM_ACT_TIME', sort: true, align: 'center', width: '10', exFun:'getRecoverDate'},
				{field: 'stationName', title: 'Msg.FM.BELONGED_FACTORYNO', sort: true, align: 'center', width: '18'},
				{field: 'alarmInterval', title: 'Msg.FM.ALARM_INTERVALNO', sort: true, align: 'center', width: '10'},
				{field: 'devName', title: 'Msg.FM.ALARM_DEVNO', sort: true, align: 'center', width: '10', exFun:'setAlarmDevName'},
				{field: 'suggestion', title: 'Msg.FM.ALARM_SUGGESTION', sort: true, align: 'center', exFun:'setSuggestionFun'}
			],
			countFunction: 'setAlarmCount',
			checked: true
	};
	for(var i in typeAlarmWin){
		if(i == 0){
			continue;
		}
		if(i == -2){
			var soeObj = {
					height: 500,
					page: false,
					limit: 200,
					cols: [
					    {field: 'id', title: 'Msg.FM.IDTable', sort: true, align: 'center', width: '4'},
						{field: 'severityId', title: 'Msg.FM.PERCEIVEDSEVERITYNO', sort: true, align: 'center', width: '4', exFun:'getSeverityId'},
						{field: 'status', title: 'Msg.FM.ALARM_STATUSNO', sort: true, align: 'center', width: '4', exFun:'getIfstatus'},
						{field: 'soeName', title: 'Msg.FM.ALARM_NAMENO', sort: true, align: 'center', width: '25'},
						{field: 'raisedDate', title: 'Msg.FM.AISE_DATE', sort: true, align: 'center', width: '12', exFun:'getRaisedDate'},
						{field: 'systemDate', title: 'Msg.FM.SYSTEM_DATE', sort: true, align: 'center', width: '12', exFun:'getSystemDate'},
						{field: 'belongedFactory', title: 'Msg.FM.BELONGED_FACTORYNO', sort: true, align: 'center', width: '12'},
						{field: 'soeInterval', title: 'Msg.FM.ALARM_INTERVALNO', sort: true, align: 'center', width: '12'},
						{field: 'devName', title: 'Msg.FM.ALARM_DEVNO', sort: true, align: 'center', exFun:'setAlarmDevName'},
					],
					countFunction: 'setAlarmCount',
					checked: true
			};
			$('.'+typeAlarmWin[i]).alarmTable(soeObj);
		} else if(-1 == i){
			var overObj = {
					height: 500,
					page: false,
					limit: 200,
					cols: [
					    {field: 'id', title: 'Msg.FM.IDTable', sort: true, align: 'center', width: '4'},
						{field: 'severityId', title: 'Msg.FM.PERCEIVEDSEVERITYNO', sort: true, align: 'center', width: '4', exFun:'getSeverityId'},
						{field: 'status', title: 'Msg.FM.ALARM_STATUSNO', sort: true, align: 'center', width: '4', exFun:'getIfstatus'},
						{field: 'name', title: 'Msg.FM.ALARM_NAMENO', sort: true, align: 'center', width: '22'},
						{field: 'raisedDate', title: 'Msg.FM.AISE_DATE', sort: true, align: 'center', width: '10', exFun:'getRaisedDate'},
						{field: 'stationName', title: 'Msg.FM.BELONGED_FACTORYNO', sort: true, align: 'center', width: '18'},
						{field: 'belongInterval', title: 'Msg.FM.ALARM_INTERVALNO', sort: true, align: 'center', width: '10'},
						{field: 'devName', title: 'Msg.FM.ALARM_DEVNO', sort: true, align: 'center', width: '10', exFun:'setAlarmDevName'},
						{field: 'alarmCause', title: 'Msg.overLimitAlarm.alarmCause', sort: true, align: 'center'}
					],
					countFunction: 'setAlarmCount',
					checked: true
			};
			$('.'+typeAlarmWin[i]).alarmTable(overObj);
		} else{
			$('.'+typeAlarmWin[i]).alarmTable(objs);
		}
	}
}

var setAlarmCount = function (e, data, maxCount, tableId, setCount, confirmed){
	var type = data.alarmType;
	if(tableId && 'alarmViewBody' == tableId){
		type = 0;
	} else{
		if('soeViewBody' == tableId){
			type = -2;
		}
		if(!type){
			type = -1;
		}
	}
	var currCount = alarmCountObject[type];
	if(!currCount){
		currCount = {
				'currAllCount': 0,
				'confirmedNum': 0,
				'unConfirmed': 0
		};
		alarmCountObject[type] = currCount;
	}
	var currAllCount = currCount.currAllCount;
	var confirmedNum = currCount.confirmedNum;
	var unConfirmed = currCount.unConfirmed;
	if(e == 'delete'){
		if(currAllCount > 0){
			currAllCount--;
		}
		if(confirmed && confirmed == 'unConfirmed'){
			if(unConfirmed > 0){
				unConfirmed--;
			}
		}else{
			if(confirmedNum > 0){
				confirmedNum--;
			}
		}
	} else if(e == 'add'){
		if(currAllCount < maxCount){
			currAllCount++;
		}
		if(unConfirmed < maxCount){
			unConfirmed++;
		}
		if('ACTIVE' != data.status){
			if(confirmedNum < maxCount){
				confirmedNum++;
			}
			if(unConfirmed > 0){
				unConfirmed--;
			}
		}
	} else if(e == 'confirm'){
		if(confirmedNum < maxCount){
			confirmedNum++;
		}
		if(unConfirmed > 0){
			unConfirmed--;
		}
	} else if(e == 'update'){
		if(confirmedNum < maxCount){
			confirmedNum++;
		}
		if(unConfirmed > 0){
			unConfirmed--;
		}
	} else if(e == 'clear'){
		if(unConfirmed < maxCount){
			unConfirmed++;
		}
		if(confirmedNum > 0){
			confirmedNum--;
		}
	} else if(e == 'addrecover'){
		if(currAllCount < maxCount){
			currAllCount++;
		}
		if(confirmedNum < maxCount){
			confirmedNum++;
		}
	}
	alarmCountObject[type].currAllCount = currAllCount;
	alarmCountObject[type].confirmedNum = confirmedNum;
	alarmCountObject[type].unConfirmed = unConfirmed;
	var showAlarmType = $('.alarmWinBtn1').attr('alarmType');
	if(showAlarmType && Number(showAlarmType) == type && setCount){
		$('.overviewTotalNum').html(currAllCount);
		$('.overviewConfirmedNum').html(confirmedNum);
		$('.overviewUnConfirmedNum').html(unConfirmed);
	}
}

var showAlarmWin = function (e){
	debugger
	var bgImage = $(e).css('backgroundImage');
	if(bgImage.indexOf("2-up.png") > 0){
		
		if(parent.Cookies.get('runMode') === "IMAGE"){
			$('.alarmWinButtons').find('input[type=button]').hide();
			$('.imageAlarmBtn').show();
		}
		
		//获取常规设置
		getActiveMaxNum(true);
		//获取告警颜色
		findAlarmColorInfo(false);
		//获取声响设置
		findAlarmSoundInfo();
		if(!ifFindAlarm){
			findAlarmInfo(0);
		}
		alarmViewIfOpen = true;
		$('.closeWinTitle div').hide();
		$(e).show();
		$(e).css('backgroundImage', 'url(/images/3-down.png)');
		$('.alarmAlertWin').css('bottom', '30px');
		$('.alarmAlertWin').css('height', '300px');
		for(var type in typeAlarmWin){
			var winId = typeAlarmWin[type];
			$("#"+winId).alarmTable('updateHeight', 210);
		}
		$('.showWinTitle div').show();
		$('.showWinTitle div').attr('class', 'alarmWinBtn2 text');
		var clickAlarmType = $(e).attr('alarmType');
		$('.overviewTotalNum').html(0);
		$('.overviewConfirmedNum').html(0);
		$('.overviewUnConfirmedNum').html(0);
		$('.showWinTitle div[alarmType='+clickAlarmType+']').attr('class', 'alarmWinBtn1 text');
		$('.classHideDiv').hide();
		$('#'+typeAlarmWin[clickAlarmType]).show();
		if(0 == clickAlarmType){
			$('.alarmOverviewOther').hide();
			$('.alarmOverviewClass').show();
		} else{
			showAlarmTableWin(clickAlarmType);
		}
		
		$('.alarmWinLine').on('mousedown', function (e) {
	        isFloatLayerMoving = true;
	        e.stopPropagation();
		
	    });
		$('.alarmWinLine').on('mouseup ', function (e) {
			isFloatLayerMoving = false;
			e.stopPropagation();
		
			
	    });
	} else if(bgImage.indexOf("3-down.png") > 0){
		for(var type in typeAlarmWin){
			var winId = typeAlarmWin[type];
		//	$("#"+winId+"Table").html('');
		}
		hideAlarmWin(e);
	} else{
		var clickAlarmType = $(e).attr('alarmType');
		var currAlarmType = $('.showWinTitle div[class=alarmWinBtn1]').attr('alarmType');
		if(clickAlarmType == currAlarmType){
			return;
		}
		if(0 == clickAlarmType){
			$('.alarmOverviewOther').hide();
			$('.alarmOverviewClass').show();
		} else{
			showAlarmTableWin(clickAlarmType);
		}
		if(alarmCountObject[Number(clickAlarmType)]){
			$('.overviewTotalNum').html(alarmCountObject[Number(clickAlarmType)].currAllCount);
			$('.overviewConfirmedNum').html(alarmCountObject[Number(clickAlarmType)].confirmedNum);
			$('.overviewUnConfirmedNum').html(alarmCountObject[Number(clickAlarmType)].unConfirmed);
		} else{
			$('.overviewTotalNum').html(0);
			$('.overviewConfirmedNum').html(0);
			$('.overviewUnConfirmedNum').html(0);
		}
		$('.showWinTitle div').attr('class', 'alarmWinBtn2 text');
		$('.closeWinTitle div').hide();
		$('.closeWinTitle div[alarmType='+clickAlarmType+']').show();
		$('.closeWinTitle div').css('backgroundImage', 'url(/images/2-up.png)');
		$('.closeWinTitle div[alarmType='+clickAlarmType+']').css('backgroundImage', 'url(/images/3-down.png)');
		$(e).attr('class', 'alarmWinBtn1 text');
		$('.classHideDiv').hide();
		$('#'+typeAlarmWin[clickAlarmType]).show();
	}
	scrollAutoWidth(typeAlarmWin[clickAlarmType]);
}

function hideAlarmWin(e){
	alarmViewIfOpen = false;
	$('.showWinTitle div').hide();
	$('.closeWinTitle div').hide();
	$('.closeWinTitle div').show();
	if(e){
		$(e).css('backgroundImage', 'url(/images/2-up.png)');
	} else{
		$('.closeWinTitle div').css('backgroundImage', 'url(/images/2-up.png)');
	}
	$('.alarmAlertWin').css('height', '0');
	$('.alarmAlertWin').css('bottom', '30px');
	ifFindAlarm = false;
}

function showAlarmTableWin(clickAlarmType){
	$('.alarmOverviewClass').hide();
	$('.alarmOverviewOther').show();
	var langObj = alarmBtnTypeByLang[clickAlarmType];
	$('.otherViewBtn1').attr('alarmType', clickAlarmType);
	$('.otherViewBtn1').attr('value', eval(langObj.btn1));
	$('.otherViewBtn1').attr('language', langObj.btn1);
	$('.otherViewBtn1').attr('languagetitle', langObj.btn1);
	$('.otherViewBtn2').attr('alarmType', clickAlarmType);
	$('.otherViewBtn2').attr('value', eval(langObj.btn2));
	$('.otherViewBtn2').attr('language', langObj.btn2);
	$('.otherViewBtn2').attr('languagetitle', langObj.btn2);
	$('.otherViewBtn').hide();
	$('#refBtn'+clickAlarmType).show();
}

function popAlarmFilter(){
	var objs = {};
	if(parent.Cookies.get("typeValGlob") == 'zh'){
		objs.width = 460;
	} else{
		objs.width = 685;
	}
	$("#popAlarmFilterWin").globleDialog('setWidth', objs);
	$("#popAlarmFilterWin").globleDialog("open");
	$.omcAjax("/fmFloat/findFilterAlarm", {}, function (res) {
		if(res.data){
			setFilterChecked(res.data);
		}
    });
}

function setFilterChecked(data){
	var types = data.types;
	var levs = data.levs;
	$('.alarmLevFilter').prop('checked', false);
	$('.alarmTypeFilter').prop('checked', false);
	if(levs && levs.length > 0){
		levs.map(function (e){
			$('#alarmLevel'+e).prop('checked', true);
		});
	}
	if(types && types.length > 0){
		types.map(function (e){
			var id = '';
			if('保护事件' == e){
				id = '1';
			} else if('异常告警' == e){
				id = '2';
			} else if('变位信号' == e){
				id = '3';
			} else if('通信状态' == e){
				id = '4';
			} else if('告知信息' == e){
				id = '5';
			}
			$('#alarmType'+id).prop('checked', true);
		});
	}
}

function alarmBtnSetting(){
	initSettingWin();
	$("#alarmSettingWin").globleDialog("open");
}

function initSettingWin(){
	var objs = {};
	if(parent.Cookies.get("typeValGlob") == 'zh'){
		objs.width = 485;
	} else{
		objs.width = 830;
	}
	objs.height = 300;
	$("#alarmSettingWin").globleDialog('setWidth', objs);
	$($('.settingWinTop div')[0]).click();
	getActiveMaxNum();
}

function activitedAlarmMaxnum(e){
	var val = e.value;
	if(val < 1 || val > 1000){
		e.value = '';
		$('#maxNumerrorMsgInfo').show();
		$('#maxNumerrorMsgInfo').html(Msg.FM.activeNumTip);
	} else{
		$('#maxNumerrorMsgInfo').show();
		$('#maxNumerrorMsgInfo').html(Msg.FM.rightInput);
	}
}

function checkSetTab(e){
	if(ifHideOverlimit){
		$('.overLimitHide').hide();
	} else{
		$('.overLimitHide').show();
	}
	var clsName = e.className;
	if(clsName.indexOf('selectDivClass') != -1){
		return;
	}
	$('.selectDivClass').attr('class', 'text');
	e.className = 'text selectDivClass';
	$('.settingDivClass').hide();
	var showDivid = $(e).attr('showDivid');
	$('#'+showDivid).show();
	var objs = {};
	switch (showDivid) {
		case 'colorSetDiv':
			if(parent.Cookies.get("typeValGlob") == 'zh'){
				objs.width = 520;
				objs.height = 440;
			} else{
				objs.width = 660;
				objs.height = 470;
			}
			findAlarmColorInfo();
			break;
		case 'soundSetDiv':
			if(alarmVoiceFlag){
				if(parent.Cookies.get("typeValGlob") == 'zh'){
					objs.width = 660;
					objs.height = 350;
				} else{
					objs.width = 485;
					objs.height = 350;
				}
				$('#alarmSoundDiv').hide();
				$('#alarmVoiceSoundDiv').show();
			} else{
				$('#alarmVoiceSoundDiv').hide();
				$('#alarmSoundDiv').show();
				if(parent.Cookies.get("typeValGlob") == 'zh'){
					objs.width = 700;
					objs.height = 450;
				} else{
					objs.width = 750;
					objs.height = 465;
				}
			}
			findAlarmSoundInfo();
			break;
		case 'enabledSetDiv':
			if(parent.Cookies.get("typeValGlob") == 'zh'){
				objs.width = 485;
			} else{
				objs.width = 660;
			}
			objs.height = 450;
			findAlarmEnabledInfo();
			break;
		case 'clearSettingDiv':
			if(parent.Cookies.get("typeValGlob") == 'zh'){
				objs.width = 485;
			} else{
				objs.width = 660;
			}
			objs.height = 240;
			getAlarmClearSet();
			break;
		default:
			if(parent.Cookies.get("typeValGlob") == 'zh'){
				objs.width = 485;
			} else{
				objs.width = 830;
			}
			objs.height = 300;
			$('#maxNumerrorMsgInfo').hide();
			getActiveMaxNum();
			break;
	}
	$("#alarmSettingWin").globleDialog('setWidth', objs);
}

function alarmEmabledBtn(e){
	var emableVal = $(e).attr('emableVal');
	if('1' == emableVal){
		$(e).val(Msg.FM.startUse);
		$(e).attr('emableVal', 0);
	} else{
		$(e).val(Msg.FM.stopUse);
		$(e).attr('emableVal', 1);
	}
}

function findAlarmEnabledInfo(){
	$.omcAjax("/fmFloat/enabled", {}, function (res) {
		if(res.data){
			res.data.map(function (data){
				var btnVal = data.enable;
				$('#emabled'+data.alarmType).attr('emableVal', btnVal);
				setAlarmTypeByObj(data.alarmType, btnVal);
				if(1 == btnVal){
					btnVal = Msg.FM.stopUse;
				} else{
					btnVal = Msg.FM.startUse;
				}
				$('#emabled'+data.alarmType).val(btnVal);
			});
		}
    });
}

function setAlarmTypeByObj(alarmType, btnVal){
	var type = '';
	if('protectionEvent' == alarmType){
		type = 10;
	} else if('abnormalAlarm' == alarmType){
		type = 7;
	} else if('displacementSignal' == alarmType){
		type = 2;
	} else if('communicationState' == alarmType){
		type = 11;
	} else if('informInformation' == alarmType){
		type = 12;
	} else if('overLimit' == alarmType){
		type = 14;
	}
	alarmEnableFlag[type] = btnVal;
}

function findAlarmSoundInfo(){
	$.omcAjax("/fmFloat/sound", {"configIndex": 1}, function (res) {
		if(res.data){
			var sound = res.data.sound;
			var file = res.data.file;
			alarmVoiceFlag = res.data.ifVoiceAlarm;
			sound.map(function (e){
				var alarmSoundType = e.alarmType;
            	var alarmSoundlevel = e.perceivedSeverity;
				if(alarmVoiceFlag){
					$('#voiceSound'+alarmSoundlevel).attr('enabled', e.enabled);
					var btnVal = "";
					if(1 == e.enabled){
						btnVal = Msg.FM.stopUse;
					} else{
						btnVal = Msg.FM.startUse;
					}
					$('#voiceSound'+alarmSoundlevel).val(btnVal)
					voiceLevObject[alarmSoundlevel] = e.enabled;
				} else{
					$("#soundBtnLevel"+alarmSoundlevel+alarmSoundType).html('');
					file.map(function (opt){
						$("#soundBtnLevel"+alarmSoundlevel+alarmSoundType).append("<option value='"+opt.name+"'>"+opt.name+"</option>");
					});
	            	var soundName = e.name;
	            	$("#soundBtnLevel"+alarmSoundlevel+alarmSoundType).val(soundName);
	            	audioObjs[alarmSoundlevel+''+alarmSoundType] = soundName;
				}
			});
		}
    });
}

function findAlarmColorInfo(sync){
	if(sync == undefined){
		sync = true;
	}
    $.omcAjax("/fmFloat/findAlarmColor", {"configIndex": 1}, function (res) {
		if(res.data){
			var setColor = res.data;
			setAlarmColorInfo(setColor, sync);
		}
    }, sync);
}

function setAlarmColorInfo(setColor, ifreload){
	for(var i in setColor){
		var colorValue = setColor[i].colorValue;
		if(colorValue.startsWith('#')){
			colorValue = colorValue.substring(1, colorValue.length);
		}
		alarmColorObj[Number(setColor[i].perceivedSeverity+1)+''+setColor[i].alarmType] = colorValue;
		var inputId = "colorBtnLevel"+setColor[i].perceivedSeverity+''+setColor[i].alarmType;
		if(colorValue != null && colorValue.trim() != ""){
			$("#"+inputId).css("backgroundColor", "#"+colorValue);
			$("#"+inputId).attr('buttonColor', colorValue);
		}else{
			$("#"+inputId).css("backgroundColor", "#"+setColor[i].initColorValue);
		}
		$("#"+inputId).attr('alarmType', setColor[i].alarmType);
		$("#"+inputId).attr('alarmLev', setColor[i].perceivedSeverity);
		$("#"+inputId).colpick({
            colorScheme: 'dark',
            onSubmit:function(hsb,hex,rgb,el) {
            	$(el).css('background-color', '#'+hex);
            	$(el).val("");
                var cid = $(this.el.outerHTML).attr("id");
                cid = cid.substring(1, cid.length);
                var chartColor = '#'+hex;
                $(el).attr("buttonColor", chartColor);
                $(el).colpickHide();
            }
        });
	}
}

function getActiveMaxNum(sync){
	var ifsync = true;
	if(sync){
		ifsync = false;
	}
	$.omcAjax("/fmFloat/common", {}, function (res) {
		if(res.data){
			if(res.data.isActiveWindow){
				$('input[name=activeAlarmWindow]')[0].checked = true;
				$('input[name=activeAlarmWindow]')[1].checked = false;
				alarmViewIfAlart = true;
			} else{
				$('input[name=activeAlarmWindow]')[0].checked = false;
				$('input[name=activeAlarmWindow]')[1].checked = true;
				alarmViewIfAlart = false;
			}
			$('#activitedAlarmMaxNum').val(res.data.maxActivedNum);
			for(var i in typeAlarmWin){
				$('#'+typeAlarmWin[i]).alarmTable('updateLimit', res.data.maxActivedNum);
			}
		}
    }, ifsync);
}

function alarmFloatPlayMusic(e){
	if(e){
		var musicName = e.value;
		var src = "/module/fm/music/" + musicName;
		var au = document.getElementById("alarmAudio");	
        if (oldAlarmSoundName == musicName) {
            if (!au.paused) {
                au.pause();
            } else {
                au.src = src;
                au.play();// 试听的时候播放声响
            }
        } else {
            au.src = src;
            au.play();// 试听的时候播放声响
            oldAlarmSoundName = musicName;
        }
	}
}

var setSuggestionFun = function(e){
	return '<div class="clickable-text text" language="Msg.FM.repairSuggestion" alarmId="'+e.id+'" onclick="showAlarmSuggestion(this)">'+Msg.FM.repairSuggestion+'</div>';
}

var setAlarmTypeFun = function(e){
	if(alarmTypeToLang[e.alarmType]){
		return '<div class="text" language="'+alarmTypeToLang[e.alarmType]+'">'+eval(alarmTypeToLang[e.alarmType])+'</div>';
	}
	return '';
}


/**
 * 确认告警
 */
function otherViewBtn1(){
	App.myConfirm(Msg.FM.sureConfirmAlarm, function(){
		var showAlarmTab = $('.alarmWinBtn1 ').attr('alarmType');
		var winId = typeAlarmWin[showAlarmTab];
		if(!winId){
			winId = 'testAlarmWin';
		}
		var alarmIds = $('#'+winId).alarmTable('clickedId');
		$.omcAjax("/fmFloat/confirmAlarm", {'alarmIds': alarmIds, 'alarmType': showAlarmTab}, function (res) {});
	});
}

/**
 * 清除告警
 */
function otherViewBtn2(){
	App.myConfirm(Msg.FM.sureClearAlarm, function(){
		var showAlarmTab = $('.alarmWinBtn1 ').attr('alarmType');
		var winId = typeAlarmWin[showAlarmTab];
		if(!winId){
			winId = 'testAlarmWin';
		}
		var alarmIds = $('#'+winId).alarmTable('clickedId');
		if(!alarmIds || alarmIds.length < 1){
			alarmIds = [];
			var alarmChecks = $('#'+winId).find('tr div[id=alarmConf]');
			for(var i=0; i<alarmChecks.length; i++){
				var lan = $(alarmChecks[i]).attr('language');
				if('Msg.fmmenu.yesSure' == lan){
					alarmIds.push(alarmChecks[i].parentNode.parentNode.id);
				}
			}
		}
		$.omcAjax("/fmFloat/clearAlarm", {'alarmIds': alarmIds, 'alarmType': showAlarmTab}, function (res) {});
	});
}

function listenerFmSocket(data){
	if(data){
		var operation = data.operation;
	    var operationData = data.operationData;
	    var type = operationData.type;
	    if(!type){
	    	type = operationData.alarmType;
	    }
	    if('changeColor' == operation){
	    	//颜色
	    	setAlarmColorInfo(operationData.colorData);
	    } else if('changeCommonSetting' == operation){
	    	//常规设置
	    	if(operationData.oper && operationData.oper == "save"){
	    		getActiveMaxNum();
	    	} else{
	    		setCommonInfo();
	    	}
	    } else if('changeAudio' == operation){
	    	//声响设置
	    	var sounds = operationData.sounds;
	    	sounds.map(function (e){
	    		$("#soundBtnLevel"+e.perceivedSeverity+""+e.alarmType).val(e.name);
	    		audioObjs[e.perceivedSeverity+""+e.alarmType] = e.name;
	    	});
	    } else if('changeAlarmEnable' == operation){
	    	//声响禁用设置
	    	var enables = operationData.enable;
	    	enables.map(function (e){
	    		var btnVal = e.enable;
				$('#emabled'+e.alarmType).attr('emableVal', btnVal);
				if(1 == btnVal){
					btnVal = Msg.FM.stopUse;
				} else{
					btnVal = Msg.FM.startUse;
				}
				$('#emabled'+e.alarmType).val(btnVal);
	    	});
	    } else if('alarmClear' == operation){
	    	//告警清除设置
	    	var clears = operationData.clears;
	    	clears.map(function (e){
	    		var lev = e.alarmSeverityLevel;
	    		var checked = e.alarmClearShow == 1 ? true:false;
	    		if(1 == lev){
	    			$("#importantBox").prop('checked', checked);
	    		} else if(2 == lev){
	    			$("#secondaryBox").prop('checked', checked);
	    		} else{
	    			$("#suggestiveBox").prop('checked', checked);
	    		}
	    		clearObject[lev] = e.alarmClearShow;
	    	});
	    } else if('stopAudio' == operation){
	    	//停止音响
	    	var mAudio = document.getElementById("main_au");
            mAudio.pause();
            currAudio = {};
	    } else if('changeAlarmFilter' == operation){
	    	if(operationData.recoverFilter){
	    		$('.alarmLevFilter').prop('checked', false);
				$('.alarmTypeFilter').prop('checked', false);
	    	} else{
	    		setFilterChecked(operationData);
	    	}
	    } else if('confirmAlarm' == operation){
	    	var referer = parent.Cookies.get("Referer");
	    	if(referer && referer == 'COMC'){
	    		return;
	    	}
	    	//确认告警
	    	var winId = typeAlarmWin[operationData.alarmType];
			if(!winId){
				winId = 'testAlarmWin';
			}
			operationData.arrays.map(function (e){
				$('#'+winId).alarmTable('update', e);
				if(operationData.alarmType > 0){
					$('#'+typeAlarmWin[0]).alarmTable('update', e);
				}
				if(currAudio[e.id]){
					delete currAudio[e.id];
					var mAudio = document.getElementById("main_au");
					mAudio.pause();
				}
			});
	    } else if('refreshAlarm' == operation){
	    	var referer = parent.Cookies.get("Referer");
	    	if(referer && referer == 'COMC'){
	    		return;
	    	}
	    	//清除告警
	    	var winId = typeAlarmWin[operationData.alarmType];
			if(!winId){
				winId = 'testAlarmWin';
			}
			operationData.arrays.map(function (e){
				var oper = 'delete';
				if(clearObject[e.severityId] && !e.ackDate){
					oper = 'update';
				}
				if(e.act == 'TELE_RECOVER'){
					oper = 'delete';
				}
				$('#'+winId).alarmTable(oper, e);
				if(operationData.alarmType > 0){
					$('#'+typeAlarmWin[0]).alarmTable(oper, e);
				}
				if(currAudio[e.id]){
					delete currAudio[e.id];
					var mAudio = document.getElementById("main_au");
					mAudio.pause();
				}
			});
	    } else if('newAlarm' == operation){
	    	// 集控收到告警
	    	addAlarmFloat(data);
	    }
	}
}

function showAlarmSuggestion(e){
	var alarmId = $(e).attr('alarmId');
	$.omcAjax("/fmFloat/getSuggestion", {'alarmId':alarmId}, function (res) {
		if(res.data){
			$('#suggestionTbo').html('');
			res.data.map(function (e){
				var objs = e;
				var sugges1 = e[1];
				if(!sugges1){
					sugges1 = "N/A";
				}
				var sugges2 = e[2];
				if(!sugges2){
					sugges2 = "N/A";
				}
				$('#suggestionTbo').append('<tr><td>'+e[0]+'</td><td>'+sugges1+'</td><td>'+sugges2+'</td></tr>');
			});
			$("#showSuggestionWin").globleDialog('open');
		} else{
			App.myMsg(Msg.FM.notCachedErr);
		}
    });
}

function getAlarmClearSet(){
	$.omcAjax("/fmFloat/getAlarmClearSet", {}, function (res) {
		if(res.data){
			res.data.map(function (e){
				clearObject[e.alarmSeverityLevel] = e.alarmClearShow;
				var lev = e.alarmSeverityLevel;
	    		var checked = e.alarmClearShow == 1 ? true:false;
	    		if(1 == lev){
	    			$("#importantBox").prop('checked', checked);
	    		} else if(2 == lev){
	    			$("#secondaryBox").prop('checked', checked);
	    		} else{
	    			$("#suggestiveBox").prop('checked', checked);
	    		}
			});
		}
	});
}

/**
 * 让原代码调用，容错
 */
function sationChange(){}

/**
 * 人声告警启用关闭
 * @param ifVoice
 */
function systemSetSound(ifVoice){
	if(alarmVoiceFlag == ifVoice){
		return;
	}
	alarmStopAudio();
	alarmVoiceFlag = ifVoice;
	findAlarmSoundInfo();
}

var findAlarmInfo = function (type){
	loadOldAlarm = true;
	alarmCountObject = {};
    $.omcAjax("/fmFloat/getAlarmInfoByType", {'types':type}, function (res) {
		if(res.data){
			var alarms = res.data;
			for(var alarm in alarms){
				if(alarm == 'stations'){
					userStations = alarms[alarm];
					continue;
				}
				ifFindAlarm = true;
				var winId = typeAlarmWin[alarm];
				delete alarmCountObject[alarm];
				reloadCount++;
				$('#'+winId).alarmTable('reload', alarms[alarm]);
			}
		} else{
			//出现首次登陆，无法获取station
			ifFindAlarm = false;
		}
    });
	$('#'+typeAlarmWin[0]).show();
}

function disableAudio(e) {
	if(ifDisableAudio){
		e.value = Msg.FM.forbiddenAudio;
		$(e).attr("language", "Msg.FM.forbiddenAudio");
		$(e).attr("languagetitle","Msg.FM.forbiddenAudio");;
		ifDisableAudio = false;
	} else{
		e.value = Msg.FM.startAudio;
		$(e).attr("language", "Msg.FM.startAudio");
		$(e).attr("languagetitle","Msg.FM.startAudio");
		ifDisableAudio = true;
		alarmStopAudio();
	}
}

window.onresize = function(){
	if(alarmViewIfOpen){
		return;
	}
	$('.alarmAlertWin').css('bottom', '30px');
}