var keyAlarmPicInterval;//关键告警标签定时器
var intimeAlarmDataInterval;//实时告警数据定时器
var intimeAlarmStationInterval;//实时告警电站定时器
var keyAlarmDataInterval;//关键告警数据定时器
var keyAlarmStationInterval;//关键告警电站定时器
var overTimeAlarmDataInterval;//超市未处理告警数据定时器
var overTimeAlarmStation;//超市未处理告警电站定时器

var buttonIdsArr = [];
/**
 * 初始化界面
 */
$(function() {
	$("#alarmLevel").hide();
	checkRight();
	/**
	 * 电站状态、超时未处理告警、实时告警按钮上的数据定时器设置
	 */
//	window.setInterval(loadStationMonitorData,60*1000);
//	window.setInterval(loadTimeoutAlarm,60*1000);
//	window.setInterval(loadIntimeAlarm,60*1000);
	
	$("#index-top").show();
	$("#stationMonitor_title").show();
	$("#mainBody").show();
	var iscs = parent.Cookies.get('iscs') || parent.Cookies.getCook("iscs");
	if(!iscs || iscs!=="cs"){
		//浏览器
		//if(parent.Cookies.get('comcHasSSO')=="true"){
			cacheCheck();
		//}
	}
	loadAlarmCountInformation();
});
function cacheCheck(){
	// $.omcAjax("/brow/chachCheck",{"type":"check"},function(data){
	// 	if(!data.success){
	// 		App.myConfirm(Msg.errorInfo.browCahcts,function(){
	// 			$.omcAjax("/brow/chachCheck",{"type":"save"},function(data){
	//
	// 			});
	// 		});
	// 	}
	// });
}
/**
 * 验证权限
 */
function checkRight() {
	$.omcAjax("/staff/auth",{},function(res){
		if(res.success) {
			var data = res.data;
			var sysMenu = data;
			sysMenu = App.getLevelRight(sysMenu);
			if(sysMenu && sysMenu.length >0){
				for(var i=0;i<sysMenu.length;i++){
					var buttonId = sysMenu[i];
					if(buttonId.level == 1){
						var auId = buttonId.id;
						if(auId == "comcstationStatus"|| auId == "comcintimeAlarmMenu" || auId == "comchandleOverTimeAlarmMenu"){
							buttonIdsArr.push(auId);
							$("#"+auId).show();
						}						
					}
				}				
			}else {
				$("#comcintimeAlarmMenu").hide();
				$("#comchandleOverTimeAlarmMenu").hide();
				$("#comcstationStatus").hide();
			}
			if(buttonIdsArr != null && buttonIdsArr.length > 0) {
				var arrLen = buttonIdsArr.length;
				var haveStatus = false;
				for ( var i = 0; i < arrLen; i++) {
					var id = buttonIdsArr[i];
					if(id == "comcstationStatus") {
						loadStationMonitorData();
						if(arrLen<2){
							$("#comcstationStatus").css('margin-left','41.5%');
						}else if(arrLen<3){
							$("#comcstationStatus").css('margin-left','32.4%');
						}
						haveStatus = true;
						window.setInterval(loadStationMonitorData,60*1000);
					}else if(id == "comcintimeAlarmMenu" || id == "comchandleOverTimeAlarmMenu"){
						$("#alarmLevel").show();
						loadButtonDataShow();
						if(!haveStatus){
							if(arrLen>1){
								$("#comchandleOverTimeAlarmMenu").css('margin-left','32.4%');
							}else if(id == "comcintimeAlarmMenu"){
								$("#comcintimeAlarmMenu").css('margin-left','41.5%');
							}else{
								$("#comchandleOverTimeAlarmMenu").css('margin-left','41.5%');
							}
						}
						window.setInterval(loadButtonDataShow,60*1000);						
					}
				}				
				loadUrl(buttonIdsArr[0]);
			}
			$(".stationMonitorTopLeft").css("background","url('/images/mainMenu/stationMonitor2.png') 0 0 no-repeat");
		}
	});
}

/**
 * 定时器设置
 * @param timeout
 * @param id
 */
function setIntervalById(timeout,id) {
	if(id == "intimeAlarmMenu") {
		closePush();
		keyAlarmPicInterval = window.setInterval(loadKeyAlarm,timeout);
		intimeAlarmDataInterval = window.setInterval(loadintimeAlarmData,timeout);
		intimeAlarmStationInterval = window.setInterval(loadIntimeAlarmStationNum,timeout);
	}else if(id == "keytimeAlarmMenu") {
		closePush();
		keyAlarmDataInterval = window.setInterval(searchKeyAlarm,timeout);
		keyAlarmStationInterval = window.setInterval(loadKeyAlarmStationNum,timeout);
	}else if(id == "handleOverTimeAlarmMenu") {
		closePush();
		keyAlarmPicInterval = window.setInterval(loadKeyAlarm,timeout);
		overTimeAlarmDataInterval = window.setInterval(loadOvertimeAlarmData,timeout);
		overTimeAlarmStation = window.setInterval(getStationInfoByInput,timeout);
	}
	clearInvervalById(id);
}
/**
 * 清除定时器方法
 * @param id
 */
function clearInvervalById(id) {
	if(id == "intimeAlarmMenu") {
		clearInterval(keyAlarmDataInterval);
		clearInterval(keyAlarmStationInterval);
		clearInterval(overTimeAlarmDataInterval);
		clearInterval(overTimeAlarmStation);
	}else if(id == "keytimeAlarmMenu") {
		clearInterval(overTimeAlarmStation);
		clearInterval(overTimeAlarmDataInterval);
		clearInterval(keyAlarmPicInterval);
		clearInterval(intimeAlarmStationInterval);
		clearInterval(intimeAlarmDataInterval);
	}else if(id == "handleOverTimeAlarmMenu") {
		clearInterval(keyAlarmStationInterval);
		clearInterval(keyAlarmDataInterval);
		clearInterval(intimeAlarmStationInterval);
		clearInterval(intimeAlarmDataInterval);
	}else if(id == "stationStatus") {//电站状态
		clearInterval(keyAlarmStationInterval);
		clearInterval(keyAlarmDataInterval);
		clearInterval(intimeAlarmStationInterval);
		clearInterval(intimeAlarmDataInterval);
		clearInterval(overTimeAlarmStation);
		clearInterval(overTimeAlarmDataInterval);
		clearInterval(keyAlarmPicInterval);
	}
}

/**
 * 根据传入的id跳转到对应的界面
 * @param id
 */
function loadUrl(id) {
	var t = new Date().getTime();
	var url = omc[id].defPage.url;
	
//	$("#loadDataDiv").html('');
	if(id == "comcstationStatus") {
		buttonImgShow("","stationMonitorTopLeft","stationMonitorTopCenter","stationMonitorTopRight");
	}else if(id == "comchandleOverTimeAlarmMenu") {
		buttonImgShow("","stationMonitorTopCenter","stationMonitorTopLeft","stationMonitorTopRight");
	}else if(id == "comcintimeAlarmMenu") {
		buttonImgShow("","stationMonitorTopRight","stationMonitorTopCenter","stationMonitorTopLeft");
	}else {
		buttonImgShow("hide","stationMonitorTopRight","stationMonitorTopCenter","stationMonitorTopLeft");
	}
	if(id == "comcstationStatus") {
		$(".rightList").hide();//暂时隐藏此处的按钮
		$(".key_alarm_prompt").hide();
	}else if(id == "keytimeAlarmMenu") {
		$(".key_alarm_prompt").hide();
	}else {
		$(".rightList").hide();
		$(".key_alarm_prompt").show();
	}
	$("#loadDataDiv").load(url + "?t=" + t);
}

/**
 * 按钮样式的展示
 * @param hide
 * @param showId
 * @param hideId1
 * @param hideId2
 */
function buttonImgShow(hide,showId,hideId1,hideId2) {
	if(hide == "") {
		$("."+showId).css("background","url('/images/mainMenu/stationMonitor2.png') 0 0 no-repeat");
	}else {
		$("."+showId).css("background","url('/images/mainMenu/stationMonitor1.png') 0 0 no-repeat");
	}
	$("."+hideId1).css("background","url('/images/mainMenu/stationMonitor1.png') 0 0 no-repeat");
	$("."+hideId2).css("background","url('/images/mainMenu/stationMonitor1.png') 0 0 no-repeat");
}

/**
 * 加载电站状态图表
 */
function loadPicList() {
	$("#stationStatusDataDiv").hide();
	loadUrl('stationStatus');
}
/**
 * 加载电站状态列表
 */
function loadNameList() {
	return false;
	$("#stationStatusDataDiv").show();
	var stationStatusDataDiv = $("#stationStatusDataDiv");
	$("#loadDataDiv").html('');
	$("#loadDataDiv").append(stationStatusDataDiv);
	loadStationStatusDataList();
}

var parm = {};
parm.pageIndex = 1;
parm.pageSize = 8;
parm.stationName = "";
/**
 * 按钮数据展示
 */
function loadButtonDataShow() {
	$.omcAjax("/comcFM/getButtonData",parm,function(res) {
		if(res.success) {
			var data = res.data;
			var timeOutData = data.timeOutData;
			if(timeOutData != undefined) {
				$("#timeoutAlarmImportant").text(timeOutData[1]);
				$("#timeoutAlarmSecondary").text(timeOutData[2]);
				$("#timeoutAlarmPrompt").text(timeOutData[3]);
			}else {
				$("#timeoutAlarmImportant").text(0);
				$("#timeoutAlarmSecondary").text(0);
				$("#timeoutAlarmPrompt").text(0);
			}
			
			var inTimeData = data.inTimeData;
			if(inTimeData != undefined) {
				$("#intimeAlarmImportant").text(inTimeData[1]);
				$("#intimeAlarmSecondary").text(inTimeData[2]);
				$("#intimeAlarmPrompt").text(inTimeData[3]);
			}else {
				$("#intimeAlarmImportant").text(0);
				$("#intimeAlarmSecondary").text(0);
				$("#intimeAlarmPrompt").text(0);
			}
			
			var keyAlarmData = data.keyAlarmData;
			if(keyAlarmData != undefined) {
				var belongSpan = $("#overTimeTotalAlarmSpan");
				belongSpan.html("");
				var keyAlarmTurn = '<span language="Msg.inOroverTimeAlarm.total" class="text">'+Msg.inOroverTimeAlarm.total+'</span>'+0+'<span language="Msg.inOroverTimeAlarm.keyAlarm" class="text">'+Msg.inOroverTimeAlarm.keyAlarm+'</span>';
				if(keyAlarmData > 0){
					keyAlarmTurn = '<span language="Msg.inOroverTimeAlarm.total" class="text">'+Msg.inOroverTimeAlarm.total+'</span>'+'<span class="key_alrm_num">'+keyAlarmData+'</span>'+'<span language="Msg.inOroverTimeAlarm.keyAlarm" class="text">'+Msg.inOroverTimeAlarm.keyAlarm+'</span>';
					$("#overTimeKeyAlarmBtn").removeClass("key_alarm_green_btn");
					$("#overTimeKeyAlarmBtn").addClass("key_alarm_red_btn");
				}else{
					$("#intimeKeyAlarmBtn").removeClass("key_alarm_red_btn");
					$("#intimeKeyAlarmBtn").addClass("key_alarm_green_btn");
				}
				belongSpan.append(keyAlarmTurn);
			}else {
				belongSpan.append(keyAlarmTurn);
			}
		}else {
			$("#timeoutAlarmImportant").text(0);
			$("#timeoutAlarmSecondary").text(0);
			$("#timeoutAlarmPrompt").text(0);
			
			$("#intimeAlarmImportant").text(0);
			$("#intimeAlarmSecondary").text(0);
			$("#intimeAlarmPrompt").text(0);
			var belongSpan = $("#overTimeTotalAlarmSpan");
			belongSpan.html("");
			var keyAlarmTurn = '<span language="Msg.inOroverTimeAlarm.total" class="text">'+Msg.inOroverTimeAlarm.total+'</span>'+0+'<span language="Msg.inOroverTimeAlarm.keyAlarm" class="text">'+Msg.inOroverTimeAlarm.keyAlarm+'</span>';			
			belongSpan.append(keyAlarmTurn);
		}
	});
}
/**
 * 加载电站状态的电站个数
 */
function loadStationMonitorData() {
	parm = {};
	parm.type = 1;
	$.omcAjax("/stationStatus/getStationCount",parm,function(res) {
		if(res.success) {
			var data = res.data;
			$("#stationDataNum").text(data);
		}else {
			$("#stationDataNum").text(0);
		}
	});
}
/**
 * 加载电站状态的数据列表
 */
function loadStationStatusDataList() {
	
}
/** 取消订阅 */
function closePush() {
    parent.Webchannel.stopPush("allDevSignalSocketListener");
    parent.Webchannel.stopPush("StationStatusAutoGenerateSocketListener");
}

/**
 * 显示告警统计下方提示文字
 */
function loadAlarmCountInformation() {
	debugger
	$.omcAjax("/timeoutAlarm/getAlarmCountSetting",{},function(res) {
		if(res.success) {
			var data = res.data;
			var redPartSelect = data[0].alarmType;
			var yellowPartSelect = data[1].alarmType;
			var bluePartSelect = data[2].alarmType;
			redPartSelect = alarmTypeChange(redPartSelect);
			yellowPartSelect = alarmTypeChange(yellowPartSelect);
			bluePartSelect = alarmTypeChange(bluePartSelect);
			if(redPartSelect == null && yellowPartSelect == null && bluePartSelect == null){
				$("#redInfomation").val(Msg.rwmenu.centralized.timeoutAlarm.important);
				$("#redInfomation").attr("language","Msg.rwmenu.centralized.timeoutAlarm.important");
				$("#yellowInfomation").val("Msg.rwmenu.centralized.timeoutAlarm.secondary");
				$("#yellowInfomation").attr("language","Msg.rwmenu.centralized.timeoutAlarm.secondary");
				$("#blueInfomation").val(Msg.rwmenu.centralized.timeoutAlarm.prompt);
				$("#blueInfomation").attr("language","Msg.rwmenu.centralized.timeoutAlarm.prompt");
				$("#redInfomation2").val(Msg.rwmenu.centralized.timeoutAlarm.important);
				$("#redInfomation2").attr("language","Msg.rwmenu.centralized.timeoutAlarm.important");
				$("#yellowInfomation2").val("Msg.rwmenu.centralized.timeoutAlarm.secondary");
				$("#yellowInfomation2").attr("language","Msg.rwmenu.centralized.timeoutAlarm.secondary");
				$("#blueInfomation2").val(Msg.rwmenu.centralized.timeoutAlarm.prompt);
				$("#blueInfomation2").attr("language","Msg.rwmenu.centralized.timeoutAlarm.prompt");

			}else{
				$("#redInfomation").text(redPartSelect);
				$("#yellowInfomation").text(yellowPartSelect);
				$("#blueInfomation").text(bluePartSelect);
				$("#redInfomation2").text(redPartSelect);
				$("#yellowInfomation2").text(yellowPartSelect);
				$("#blueInfomation2").text(bluePartSelect);
			}
		}
	});
}

function alarmTypeChange(alarmType){
	switch (alarmType){
		case 1:
		    return 'Msg.fmmenu.protectionEventTab';
		    break;
		case 2:
		    return 'Msg.fmmenu.abnormalAlarmTab';
		    break;
		case 3:
		    return 'Msg.fmmenu.displacementSignalTab';
		    break;
		case 4:
		    return 'Msg.fmmenu.communicationStateTab';
		    break;
		case 5:
		    return 'Msg.fmmenu.informInformationTab';
		    break;
		default:
            return alarmType;
            break;
	}
}

