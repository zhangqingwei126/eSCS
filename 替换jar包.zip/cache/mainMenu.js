var runMode = parent.Cookies.get('ComcMode');
var hasZtmen = false;
var hasSystem = false;
var hasCOMCSystem = false;
//智能诊断
$(function(){
	$.omcAjax("/check/getSysParm",{},function(data){
		if(data.success){
			parent.Cache.stationCache = data.data.stationCache;
			parent.Cookies.setSessionId(data.data.JSESSIONID);
			parent.Cache.stations = data.data.stations;
			parent.Cache.comcStations = data.data.comcStations;
			parent.App.user.stations = data.data.stations;
			parent.App.user.comcStations = data.data.comcStations;
            var dataTemp = data.data;
            if(dataTemp.hasOwnProperty('isTwaver') && dataTemp.isTwaver == 'true'){
                Cookies.setCook("isTwaver",dataTemp.isTwaver.trim());
            }

            if(dataTemp.hasOwnProperty('destination') && dataTemp.destination){
                Cookies.setCook("destination",dataTemp.destination.trim());
            }

            if(dataTemp.hasOwnProperty('destinationName') && dataTemp.desinationName){
                Cookies.setCook("destinationName",dataTemp.desinationName.trim());
            }
            if(dataTemp.hasOwnProperty('subId') && dataTemp.subId){
                Cookies.setCook("subId",dataTemp.subId.trim());
            }
            if(dataTemp.hasOwnProperty('subAreaId') && dataTemp.subAreaId){
                Cookies.setCook("subAreaId",dataTemp.subAreaId.trim());
            }
            if(dataTemp.hasOwnProperty('devId') && dataTemp.devId){
                Cookies.setCook("devId",dataTemp.devId.trim());
            }
            if(dataTemp.hasOwnProperty('mycolor') && dataTemp.mycolor){
                Cookies.setCook("mycolor",dataTemp.mycolor.trim());
            }
            if(dataTemp.hasOwnProperty('message') && dataTemp.message){
                Cookies.setCook("message",dataTemp.message.trim());
            }

		}
	},false);
	if(parent.Cookies.get("comcHasSSO") && parent.Cookies.get("comcHasSSO")=='true'){
		// broCheck();
	}
	$.omcAjax("/stationUpgrade/query",{}, function(data) {
		 if(data.success == true && data.params){
			if(data.params == "true"){
				var hurl = omc.systemset.defPage.url;
	    		if(hurl.indexOf('?')<0){
	    			hurl = hurl+"?v="+parent.omc.defaultcode;
	    		}
				window.location.href = hurl+"&turnId="+"stationCofSystem&pid="+"sysSystem";
			}else {
				var nums = 0;
				for(var k in parent.App.user.stations){
					if(k){
						nums++;
					}
				}
				if(runMode=="COMC" || nums==1){
					$('#returnHomeId').hide();
				}else{
					$('#returnHomeId').show();
				}
				if(undefined == Msg){
					var hurl = omc.index.url;
    				if(hurl.indexOf('?')<0){
    					hurl = hurl+"?v="+parent.omc.defaultcode;
    				}
					window.location.href = hurl;
					window.event.returnValue = false;
					return;
				}
				$("#alarm_float_layout", window.parent.document).prop("hidden", true);
				if(parent.ifLocalAlarm){
					$('.alarmAlertWin', window.parent.document).css('display', 'none');
					parent.hideAlarmWin();
				}
				if(runMode && runMode=='COMC'){
					$('#pageSpantitle').html(Msg.pageTitleComc);
					$('#pageSpantitle').attr('language','Msg.pageTitleComc');
					$('#pageSpantitle').addClass('text');
				}else{
					$('#pageSpantitle').html($('#stationsSelects option:selected').html());
				}
				if(document.referrer.indexOf('ztpz') > 0){
					parent.hideHead = false;
					document.getElementById('yincang').className = "yincang";
					document.getElementById('index-top').style.display = "block";
					if (document.getElementById('mainMenu') != null) {
						document.getElementById('mainMenu').className = 'daohang';
					}
				}
				/**
				 * Token 校验
				 */
				$.omcAjax("/check/checkToken",{},function(data){
					if(!data || !data.success){
						var hurl = omc.index.url;
	    				if(hurl.indexOf('?')<0){
	    					hurl = hurl+"?v="+parent.omc.defaultcode;
	    				}
						window.location.href = hurl;
						window.event.returnValue = false;
					}
				});

//				if(runMode == "COMC"){
//					loadMainUrl("comcstationmonitor");
//				}
				/**
				 * 主目录菜单生成
				 */
				debugger
				var mainDh = $("#mainMenu");
				var ul = $('<ul></ul>');
				var stationInfoDiv = $('<div id="stationInfoDiv"></div>'); //电站信息按钮框
				var stationViewDiv = $('<div id="stationViewDiv"></div>');//相关视图按钮框（主接线、分区、子阵、电站）
				var stationFncDiv  = $('<div id="stationFncDiv"></div>'); //其他电站功能按钮框
				var stationMonitorCOMC = $('<div id="comcstationMonitorCOMC"></div>');//电站监控
				var plantDiCOMC = $('<div id="comcplantDiCOMC"></div>');//电站数字化和系统工具
				var stationViewBtn = []; // 记录生成的视图相关按钮id
				$.omcAjax("/staff/auth",{},function(data){
					if(data && data.success){
						var flag = false;
						var firstId;
						parent.isCheck = false;
						parent.App.user.stationCounts =data.params[0]; 
//        	parent.App.user.stationCounts = 1;
						var curStationCode = parent.App.curStationNumber;
						
						$.omcHttp.GET('/station/staticInfo?stationCode='+curStationCode, function (res) {
							debugger;
							if (res && res.success && res.data) {
								parent.App.user.plantStationCode = res.data.stationNumber;
								if(res.data.combinedType == 2){
									flag = true;
								}
							}
							var sysMenu = data.data;
							sysMenu = App.getLevelRight(sysMenu);
							if(sysMenu && sysMenu.length>0){
								for(var i=0;i<sysMenu.length;i++){
									var element = sysMenu[i];
									if(element.level==1){
										var id = element.id;
										if(id == "ztmenu" ||id == "comcztmenu"){
											hasZtmen = true;
											if(runMode !='COMC' && parent.App.user.stationCounts<=1){
												element.type="";
											}
										}else if(id =="sysSystem"){
											hasSystem = true;
										}else if(id == "comcrwmenu"){
											hasCOMCSystem = true;
										}
										if('hjzmenu' == id || "dmodmenu" == id || "fqztmenu" == id 
												||'comchjzmenu' == id || "comcdmodmenu" == id || "comcfqztmenu" == id){
											if(runMode && runMode=='COMC'){
												continue;
											}
										} 
										if(('stationIndexChart' == id) && flag == false){
											continue;
										}
										if('healthCheck' == id ){
											parent.isCheck = true;
										}
										var text;

										var url;
                                        if(id && omc && omc[id] && omc[id].defPage && omc[id].defPage.url){
                                            url = omc[id].defPage.url;
                                            text = element.text;
                                        }

										if(url==null || url==undefined || url==""){
											url="#";
										}
										if(runMode && runMode=='COMC'){
											$("#returnHomeId").hide();
											$('#page-title').show();
//	                        	var li = $('<li style="margin: 0 0 3% 4%;"><input language="'+text+'" id="'+id+'comc" value ="'+mac.vals(text)+
//                                '" type="button"  class="daohang-button textValue" onmouseover="this.className=\'daohang-button1 textValue\'" onmouseout="this.className=\'daohang-button textValue\'" '+
//                                ' onmousedown="this.className=\'daohang-button2 textValue\'" onclick="loadMainUrl(\''+id+'\')"/></li>');
											var li = $('<div id="'+id+'comcDiv" class="text" onclick="loadMainUrl(\''+id+'\')">'+
													'<div id="'+id+'comc" language="'+text+'" style="display:block;" class="text">'+mac.vals(text)+'</div></div>');
											if(id == "comcstationmonitor") {//电站监控
												stationMonitorCOMC.append(li);
											}else if(id == "comcztmenu") {//电站数字化
												plantDiCOMC.append(li);
											}else if(id == "comcrwmenu") {//系统工具
												plantDiCOMC.append(li);
											}
											ul.append(stationMonitorCOMC);
											ul.append(plantDiCOMC);
//	                        	ul.append(li);
										}else{
//	                        	var li = $('<li><input language="'+text+'" id="'+id+'" value ="'+mac.vals(text)+
//		                                '" type="button" class="daohang-button textValue" onmouseover="this.className=\'daohang-button1 textValue\'" onmouseout="this.className=\'daohang-button textValue\'" '+
//		                                ' onmousedown="this.className=\'daohang-button2 textValue\'" onclick="loadMainUrl(\''+id+'\')"/></li>');
											if(element.type && element.type=="SYSDEL" ){
												continue;
											}
											$('#page-title').show();
//	                        	$("#returnHomeId").show();
											var li = $('<div id="'+id+'" class="divCls" onclick="loadMainUrl(\''+id+'\')">'+
													'<div id="'+id+'Img" language="'+text+'" style="display:block;" class="text">'+mac.vals(text)+'</div></div>');
											if(id=='dzmenu'){
												stationInfoDiv.append(li);
											}else if(id=='dzwlstmenu' || id=='fqztmenu' || id=='hjzmenu' || id=='dmodmenu'){
												stationViewDiv.append(li);
												stationViewBtn.push(id);
											}else{
												stationFncDiv.append(li);
//												stationFncDiv.find('#fmmenu').css('width','292px');
//												stationFncDiv.find('#agvcmenu').css('width','292px');
//												stationFncDiv.find('#lightPowerForcastSys').css('width','292px');
//												stationFncDiv.find('#opticaltracking').css('width','292px');
												stationFncDiv.find('#fmmenu').css('width','292px');
												stationFncDiv.find('#agvcmenu').css('width','292px');
												stationFncDiv.find('#rwmenu').css('width','292px');
												stationFncDiv.find('#healthCheck').css('width','292px');
												stationFncDiv.find('#opticaltracking').css('width','292px');
												stationFncDiv.find('#stationIndexChart').css('width','292px');
												stationFncDiv.find('#lightPowerForcastSys').css('width','292px');
											}
											
										}
									}
								}
								if(runMode && runMode!='COMC'){
									var len = stationViewBtn.length;
									if(len == 1 || len == 3){
										stationViewDiv.find('#'+stationViewBtn[0]).css('width','97.5%');
									}else if(len == 2){
										stationViewDiv.find('#'+stationViewBtn[0]).css('width','97.5%');
										stationViewDiv.find('#'+stationViewBtn[1]).css('width','97.5%');
									}
									if(parent.App.user.stationCounts<=1){
										stationFncDiv.find('#fmmenu').css('width','292px');
										stationFncDiv.find('#agvcmenu').css('width','292px');
										stationFncDiv.find('#rwmenu').css('width','292px');
										stationFncDiv.find('#healthCheck').css('width','292px');
										stationFncDiv.find('#opticaltracking').css('width','292px');
										stationFncDiv.find('#stationIndexChart').css('width','292px');
										stationFncDiv.find('#lightPowerForcastSys').css('width','292px');
										if(hasZtmen && $('#ztmenSystem').length==1){
											initheader();
										}
									}else{
										if(hasZtmen && $('#ztmenSystem').length<1){
											initheader();
										}
									}
									ul.append(stationInfoDiv);
									ul.append(stationViewDiv);
									ul.append(stationFncDiv);
								}
								
							}
							mainDh.append(ul);
							if(parent.Cookies.get('ComcMode') && 
									parent.Cookies.get('ComcMode')!='COMC'){
								LicenseExpirePreTip();
							}
							$('#LicenseExpirePreTip').click();
						});
					}
				});
				if($('#stationsSelects option:selected').html() && runMode && runMode!='COMC'){
					parent.document.title  =$('#stationsSelects option:selected').html();
				}
			}
		}
	});	
	if(runMode == "COMC"){
		debugger
		//loadMainUrl('hjzmenu');
		loadMainUrl("comcstationmonitor");
	}
	if(Cookies.get("isTwaver") && Cookies.get("isTwaver") == 'true'){
		loadMainUrl('hjzmenu');
	}

	if(Cookies.get("destination") && Cookies.get("destinationName") || (Cookies.get("destination") && Cookies.get("subId"))){
		console.info("destination:"+Cookies.get("destination")+"destinationName:"+Cookies.get("destinationName"));
        var destinationName = Cookies.get("destinationName")
		var id = Cookies.get("destination");

        parent.App.schemaName = destinationName;
        parent.App.schemaType = id;

            var menu;
            switch (id){
                case "1":
                    menu ="hjzmenu";
                    break;
                case "3":
                    menu ="dmodmenu";
                    break;
                case "4":
                    menu ="sub.xianbian";
                    break;
                case "7":
                    menu ="commonshema";
                    break;
                case "10":
                    if(!parent.Cookies.get('ComcMode')==="COMC"){
                        menu ="stationStatus";
                    } else {
                        menu='stationmonitor';
                    }
                    break;
                case "14":
                    menu ="stationStatus";
                    break;
				case "8":
					menu ="stationIndexChart";
					break;
                default:
                    menu = "";
                    break;
            }
            $.omcAjax("/cm/topoNodes/getTopoNodeByNameAndType",{type:id,name:destinationName},function(res){
                if(res.success){
                    loadMainUrl1(menu,res.data);
                } else if(Cookies.get("subId")){
                    loadMainUrl1(menu,0);
				}
            },false);
        parent.App.schemaName = destinationName;

        // loadMainUrl(menu)
	}

   parent.Cookies.clearCook("isTwaver");
   parent.Cookies.clearCook("destination");
   parent.Cookies.clearCook("destinationName");

   parent.Cookies.clearCook("subId");
   parent.Cookies.clearCook("subAreaId");
   parent.Cookies.clearCook("devId");
   parent.Cookies.clearCook("mycolor");
   parent.Cookies.clearCook("message");

});


function loadMainUrl(menu){
    var url = omc[menu].defPage.url;
    window.location.href = url;
}
/**
 * 主目录跳转页面 主目录跳转的页面须配置在menu.js文件中
 */
function loadMainUrl1(id,topoId) {
    if(!id){
        return;
    }
    // var t = new Date().getTime();
    var url;
    var result = id.split('.');
    if(result && result.length > 1){
    	var context = omc[result[0]] ;
    	for (var i = 1;i<result.length;i++){
            context =context[result[i]];
		}
        url = context.url;
	} else{
        url = omc[id].defPage? omc[id].defPage.url : omc[id].url;
	}

    url = url + "?f=1"
    if(topoId != 0){
        url = url + "&topoid="+topoId;
	}


    var subAreaId = Cookies.get("subId");
    var subId = Cookies.get("subAreaId");
    var devId = Cookies.get("devId");
    var mycolor = Cookies.get("mycolor");
    var message = Cookies.get("message");

    if(subId){
        url = url + "&invId="+subId;
    }
    if(subAreaId){
        url = url + "&subId="+subAreaId;
    }
    if(devId){
        url = url + "&devId="+devId;
    }
    if(mycolor){
        url = url + "&mycolor="+mycolor;
    }
    if(message){
        url = url + "&message="+message;
    }
    if(window.frames && window.frames.length >= 1){
        window.frames[0].location.href = url+"&t="+new Date().getTime();
    } else {
        window.location.href = url+"&t="+new Date().getTime();
    }
}

//license超期提醒
function LicenseExpirePreTip(){
	if(parent.Cookies.get('ComcMode') && 
			parent.Cookies.get('ComcMode')=='COMC'){
    	return;
	}
	$.omcAjax("/license/pretip",{},function(data){
		if(data){
			if(data.success){
			   if(data.data){
				   App.connDlMsg(data.data);
				   console.info("show data:",data.data);
			   }
	  		}
			else{
				
	  		}
		}
	});
}
//system

//checkIsConfigStationNo();
//用于检测是否配置了电站编号
//function checkIsConfigStationNo(){
//	$.omcAjax("/station/isconfigstationno",{},function(data){
//	});
//}

function linkToSysConfig(){
	var t = new Date().getTime();
	var hurl = omc.rwmenu.defPage.url;
	if(hurl.indexOf('?')<0){
		hurl = hurl+"?v="+parent.omc.defaultcode;
	}
	window.location.href = hurl+"&turnId="+"stationCof";
}
/**
 * 返回多电站首页
 */
function returnHome() {
	parent.Cookies.clear('sid');
	var t = new Date().getTime();
	parent.sationChange();// 加载全局的活动告警（遥信、越限）的设置
	var hurl = omc.sysmain;
	if(hurl.indexOf('?')<0){
		hurl = hurl+"?v="+parent.omc.defaultcode;
	}
	window.location.href = hurl;
}
$('#systemSetting').bind('click',function(){
	if(runMode === "COMC"){
		return;
	}
	loadMainUrl("system");
});
function broCheck(){
	var bbh = brower.getBbh();
	var bnm = brower.getName();
	if(bnm!="chrome"){
		var obw = Msg.errorInfo.otherBrow;
		var ts = Msg.errorInfo.downSuChrom;
   	 	$("#errTs").html(App.escapseHtml(ts));
   	 	$("#errTs").attr('language','Msg.errorInfo.downSuChrom');
		App.myConfirm(obw,function(){
			window.location.href = '/brow/down?fileName=browser/chrome.exe';
			App.myMsg(Msg.errorInfo.browDeclaration,function(){
				loginOut1();
			},function(){
				loginOut1();
			});
			$('#mywin').css('left','33.5%');
		},function(){
			loginOut1();
		},function(){
			loginOut1();
		});  
	}else{
		$.omcAjax("/brow/browserInfo",{browser:bbh},function(data){
			if(data){
				if(data.success){
				    return true;
		  		}else{
	  				var dcb = Msg.errorInfo.downChromeBrow;
	  				var ts = Msg.errorInfo.downSuChrom;
	  		    	$("#errTs").html(App.escapseHtml(ts));
	  		    	$("#errTs").attr('language','Msg.errorInfo.downSuChrom');
	    			App.myConfirm(dcb,function(){
	    				window.location.href = '/brow/down?fileName=browser/chrome.exe';
	    				App.myMsg(Msg.errorInfo.browDeclaration,function(){
	    					loginOut1();
	    				},function(){
	    					loginOut1();
	    				});
	    				$('#mywin').css('left','33.5%');
	    			},function(){
	    				loginOut1();
	    			},function(){
	    				loginOut1();
	    			});
		  		}
			}
  		});
	}
}
