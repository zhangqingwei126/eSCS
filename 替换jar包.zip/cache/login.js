var code="";
var time;
//是否需要验证码
var flag = false;
//第一次请求是否完成
var clickFlag = true;
var hacs="";
$(function () {
	debugger
	initlange();
	mac.setLanguage();
	if(!Cookies.getSessionId()){
		$.omcAjax("/check/getSysParm",{},function(data){
			if(data.success){
				Cookies.setSessionId(data.data.JSESSIONID);
				Cookies.setStorge(data.data);
				initTile(data.data.ComcMode);
			}
		});
	}else{
		initTile(Cookies.get("ComcMode"));
	}
	try{
		hacs = iscs
	}catch (e) {
	}
	checkErrorTimes();
	// broCheck();
	var iscs = parent.Cookies.get('iscs');
	if(!iscs && iscs!=="cs"){
		//浏览器
		if(parent.Cookies.get('comcHasSSO')=="true"){
			cacheCheck();
		}
	}
	//LicenseExpirePreTip();
	$('#Indexbody').show();
	$('#username').focus(); 
	$('#yanzm').keydown(function(e){ 
		var curkey = e.which; 
		if(curkey == 13){ 
			if(clickFlag == true){
				$('#login').click(); 
			}
			return false; 
		} 
	}); 
	$('#username').keydown(function(e){ 
		var curkey = e.which; 
		if(curkey == 13){ 
			$('#password').focus(); 
			return false; 
		} 
	}); 
	$('#password').keydown(function(e){ 
		var curkey = e.which; 
		if(curkey == 13){ 
			$('#yanzm').focus(); 
			if(flag == false){
				if(clickFlag == true){
					$('#login').click(); 
				}
			}
			return false; 
		} 
	}); 
	
	$('#loginLogTitle').css('left',(window.innerWidth - 377)/2);
	$('.login-box').css('left',(window.innerWidth - 693)/2);
	window.onresize = function(){
		$('#loginLogTitle').css('left',(window.innerWidth - 377)/2);
		$('.login-box').css('left',(window.innerWidth - 693)/2);
	}
//	$('#username').val('admin');
//	$('#password').val('admin');
//	$('#password').focus(); 
});
$("#username").bind("focus",function(event){
	$("#passwordCapsLock").hide();
});
$("#yanzm").bind("focus",function(event){
	$("#passwordCapsLock").hide();
});
$(document).keydown(function(event){ 
	event.stopPropagation();
	var e = event||window.event;
	var keyCode  =  e.keyCode||e.which; 
	 if(keyCode == 27){
		 event.returnValue=false;   
		 return;
	 }
});
$("#password").bind("keypress",function(event){
	var e = event||window.event;
    var o = $("#passwordCapsLock");
    var oTip = o.nextSibling;
    var keyCode  =  e.keyCode||e.which; // 按键的keyCode 
    var isShift  =  e.shiftKey ||(keyCode  ==   16 ) || false ; // shift键是否按住
     if (((keyCode >=   65   &&  keyCode  <=   90 )  &&   !isShift) || ((keyCode >=   97   &&  keyCode  <=   122 )  &&  isShift) ) {
    	// Caps Lock 打开，且没有按住shift键 
   	  // Caps Lock 打开，且按住shift键
    	 o.show();
     }else{
    	 o.hide();
     }
});
function initTile(runMode){
	var mode = 'escs';
	var tsstr = 'Msg.menuTitle';
//	var bottomTitlestr = 'Msg.virtual';
	if(runMode && runMode=='COMC'){
		tsstr = 'Msg.menuComcTitle';
		mode = 'comc';
//		bottomTitlestr = 'Msg.pageTitleComc';
	}
	var ts = mac.vals(tsstr);
//	$('#infoTopTitle').html(Msg.FusionSolar);
//	$('#infoTopTitle').attr('language','Msg.FusionSolar');
//	$('#infoTopTitle').attr('languageTitle',tsstr);
//	$('#infoTopTitle')[0].title = ts;
//	
//	$('#infoBottomTitle').html(mac.vals(bottomTitlestr));
//	$('#infoBottomTitle').attr('language',bottomTitlestr);
//	$('#infoBottomTitle').attr('languageTitle',tsstr);
//	$('#infoBottomTitle')[0].title = ts;
	
	document.title = ts;
	$('#login').attr('title',Msg.login.loginTitle);
	$('#loginLogTitle').attr('title',ts);
	$('#loginLogTitle').attr('language',tsstr);
	$('#loginLogTitle').attr('languageTitle',tsstr);
	$('#loginLogTitle').attr('alt',ts);
	var loginUrl = parent.omc.logimag[mode]["login"][Cookies.get("typeValGlob")];	
	$('#loginLogTitle img').attr('src',loginUrl);
	//$('#loginLogTitle img').attr('src','/images/logo/'+mode+'_login_logo_'+Cookies.get("typeValGlob")+'.png');
}
/**
 * 验证码获取的方法
 */
function getImg(){
	if(flag==true){
		img = new Image;
		img.onload = function(){
			code = Cookies.get("verfyCode");
			Cookies.clear("verfyCode");
			//console.info("getImg:"+code);
	    };
		$('#yanzm').val('');
		var url = "/staff/verfy?t="+Math.random();
		img.src = url;
		$('#yangz').attr('src', url);
	}
};

var loginData = "";
var loginUserLock ="";
/**
 * 登录方法
 */
$('#login').click(function(){
	loginData = "";
	loginUserLock = "";
	if(clickFlag==false){
		return;
	}
	clickFlag = false;
	$("#errTs").html("");
	$("#errTs1").html("");
	$("#errTs2").html("");
	var brname = brower.getName();
	debugger
	if (check()) {
		var bbh = brower.getBbh();
		var bnm = brower.getName();
		if(bnm!="chrome" && (hacs!="iscs" || !hacs)){
			getImg();
			var obw = Msg.errorInfo.otherBrow;
			var ts = Msg.errorInfo.downSuChrom;
			$("#errTs").html(ts);
			$("#errTs").attr('language','Msg.errorInfo.downSuChrom');
			App.myConfirm(obw,function(){
				window.location.href = '/brow/down?fileName=browser/chrome.exe';
				App.myMsg(Msg.errorInfo.browDeclaration);
				$('#mywin').css('left','33.5%');
			}); 
			clickFlag = true;
		}else{
			if(brname == 'chrome'){
					if(window.fullScreenApi.supportsFullScreen){
				    	window.fullScreenApi.requestFullScreen(document.documentElement,true);
                        $("#Indexbody").height( $(window).height());
				    }
			}
			$.omcAjax("/brow/browserInfo",{browser:bbh,"iscs":hacs},function(data){
	  			if(data.success){
	  			    var loginInfo = {};
	  			    loginInfo.password = $.md5($("#password").val()); 
	  			    loginInfo.username= $("#username").val();
	  			    loginInfo.code= $("#yanzm").val();
	  			    //将cookies 清空
	  			    Cookies.set("token", "");
	  			    Cookies.set("username","");
	  			    Cookies.set("userid","");
	  			    $.omcAjax('/staff/loginStaff',loginInfo,function(data){
	  			    	loginData = "";
	  			       if (data && data.success) {
	  			    	   var bdy =  $('body');
	  			    	 bdy[0].style.backgroundImage="url('/images/bg.jpg')";
	  			    	  var loginSuccess = Msg.errorInfo.loginSuccess;
	  			    	  $("#errTs").css('color','#00de15');
	  			    	  $("#errTs").html(loginSuccess);
	  			    	   App.user = data.data;
	  			           var _date = new Date();
	  			       	   _date.setDate(_date.getDate()+1);
	  			       	   Cookies.setSessionId(data.data.JSESSIONID);
	  			       	   Cookies.set("Referer", "");
	  			           Cookies.set("token", data.params[0]);
	  			           Cookies.set("username",data.data.username);
	  			           Cookies.set("userid",data.data.userid);
	  			           Cookies.set("loginType", "NO_SSO");
	  			           setSession();
	  			    	  setTimeout(function(){
	  			    		   $.omcAjax("/staff/getResource",{},function(data){
			  			       });
			  			       if(brname=='ie'){
									var wsh = new ActiveXObject('WScript.Shell');
									wsh.ExpandEnvironmentStrings("%computername%");
									wsh.sendkeys('{F11}');
								}
		  			           if(data.params.length>1){
		  			        	   var ts = Msg.errorInfo.pwsBeforDays;
		  			        	   ts = ts.replace('{1}',data.params[1]);
		  			        	   App.myMsg(ts,function(){
		  			        		  clickFlag = true;
		  			        		  bdy.load('/newMain.html');
		  			        	   });
		  			        	   $('#myclose').click(function(){  
		  			        		  clickFlag = true;
		  			        		  bdy.load('/newMain.html');
		  			        	   });
		  			           }else{
		  			        	  clickFlag = true;
		  			        	  bdy.load('/newMain.html');
						           
		  			           }
	  			    	  },100);
	  				    }else{
	  				    	var ts;
	  				    	var times = data.params;
	  				    	if(data.data.backupMode && data.data.backupMode=="BackupStandby"){
	  				    		$("#errTs").attr('language','Msg.errorInfo.BackupStandbyNotLogin');
	  				    		$("#errTs").html(Msg.errorInfo.BackupStandbyNotLogin);
	  				    	}else{
	  				    		if(data.data.errorTimes>=3){
		  				    		flag = true;
		  				    		showYanzm();
		  				    	}
		  				    	if(times && times.length>1){
		  				    		time = parseInt(times[1]);
		  				    		$("#errTs").attr('language','Msg.errorInfo.userIsLocked');
		  				    		$("#errTs").html(Msg.errorInfo.userIsLocked.replace("{0}",time));
		  				    	}else{
		  				    		var ts1 = data.data.ts1;
		  				    		var ts2 = data.data.ts2;
		  				    		var ds1 = data.data.ds1;
		  				    		var ds2 = data.data.ds2;
		  				    		ts = data.data.ts;
		  				    		$("#errTs").html(App.escapseHtml(ts));
		  				    		$("#errTs").attr("language","");
		  				    		if(ts == Msg.errorInfo.nameOrPwdError){
		  				    			$("#errTs").attr("language",'Msg.errorInfo.nameOrPwdError');
		  				    		}else if(ts == Msg.login.lockTile){
		  				    			ts = ts.replace("{0}",ts1).replace("{1}",ts2);
		  				    			$("#errTs").html(ts);
		  				    			loginData = data.data;
		  				    		}else if(ts == Msg.login.loginSystemFail){//系统异常
		  				    			$("#errTs").html(ts);
		  				    	    	$("#errTs").attr("language",'Msg.login.loginSystemFail');
		  				    		}else if(ts == Msg.login.userAlerdlyLock){
                                        ts =ts.replace("{0}",ts1);
                                        $("#errTs").html(ts);
                                        loginUserLock = data.data;
                                    }else if(ds2 == Msg.login.userAlerdlyLock){
		  				    			ds2 =ds2.replace("{0}",ds1);
		  				    			$("#errTs").html(ds2);
		  				    			loginUserLock = data.data;
		  				    		}
		  				    		
		  				    	}
	  				    	}
	  				    	setTimeout(resetClickFlag,1000);  				    	
	  				    }
	  			      });
	  			}else{
	  				getImg();
	  				var dcb = Msg.errorInfo.downChromeBrow;
	  				var ts = Msg.errorInfo.downSuChrom;
	  				$("#errTs").html(ts);
	  			   $("#errTs").attr('language','Msg.errorInfo.downSuChrom');
	    			App.myConfirm(dcb,function(){
	    				window.location.href = '/brow/down?fileName=browser/chrome.exe';
	    				App.myMsg(Msg.errorInfo.browDeclaration);
	    				$('#mywin').css('left','33.5%');
	    			});
	    			clickFlag = true;
	  			}
	  		});
		}
	  }else{
		  getImg();
	  }
}); 
/**
 * 重置可登录点击标识
 */
function resetClickFlag(){
	clickFlag = true;
}
/**
 * 验证码的显示
 */
function showYanzm(){
	getImg();
	$('.loginYanzm').show();
//	$('#loginTable').css("margin-top",'-30px');
//	$('languageType1').css("top",'35px');
}
/**
 * 用户名  密码 验证码的一般验证
 * @returns {Boolean}
 */
function check() {
//	code = Cookies.get("verfyCode");
	//提交前干掉
    var username = $("#username").val();
    var password = $("#password").val();
    var yanzm = $("#yanzm").val();
    if (username == '' || username == null || username == undefined || username.replace(/\s+/g,"")=='') {
    	var ts = Msg.errorInfo.nameError;
    	$("#errTs").html(ts);
    	$("#errTs").attr("language",'Msg.errorInfo.nameError');
        $('#username').focus(); 
        clickFlag = true;
        return false;
    }
    if (password == '' || password == null || password == undefined) {
    	var ts = Msg.errorInfo.pwdBlank;
    	$("#errTs").html(ts);
    	$("#errTs").attr("language",'Msg.errorInfo.pwdBlank');
        $('#password').focus(); 
        clickFlag = true;
        return false;
    }
    //不区分大小写
    if(flag == true){
    	 if( yanzm == null || yanzm == undefined || code == undefined || $.md5(yanzm.toString().toUpperCase())!=code.toString()){
        	 var ts = Msg.errorInfo.yanzmError;
             $("#errTs").html(ts);
             $("#errTs").attr("language",'Msg.errorInfo.yanzmError');
        	 $('#yanzm').focus(); 
        	 $('#yanzm').val('');
        	  clickFlag = true;
             return false;
        }
    }
    $('#login').attr('title',Msg.login.loginFullTitle);
    return true;
};
/**
 * 进入登陆页面检测是否需要验证码
 */
function checkErrorTimes(){
	$.omcAjax("/brow/checkErrorTimes",{},function(data){
		if(data && data.success){
			var times = data.data;
  			var errorTimes = 0;
	  		if(times){
	  			errorTimes = times;
	  		}
		    if(errorTimes>=3){
		    	flag = true;
		    	showYanzm();
		    }
		    var isLock = data.params;
	    	if(isLock && isLock.length>1){
	    		time = parseInt(isLock[1]);
	    		$("#errTs").html(Msg.errorInfo.userIsLocked.replace("{0}",time));
	    		$("#errTs").attr('language','Msg.errorInfo.userIsLocked');
	    		//$("#errTs1").html(time);
	    		//$("#errTs2").html(Msg.errorInfo.reLoginSeconds);
	    		//$("#errTs2").attr('language','Msg.errorInfo.reLoginSeconds');
	    	}
		}
	});
}

function languageChange(lang){
	if(loginData!=""){
		var ts = (Msg.login.lockTile).replace("{0}",loginData.ts1).replace("{1}",loginData.ts2);
		$("#errTs").html(ts);
	}else if(loginUserLock!=""){
		var ds2 = (Msg.login.userAlerdlyLock).replace("{0}",loginUserLock.ds1);
		$("#errTs").html(ds2);
	}
	if(time){
		$("#errTs").attr('language','Msg.errorInfo.userIsLocked');
		$("#errTs").html(Msg.errorInfo.userIsLocked.replace("{0}",time));
	}
}
function cacheCheck(){
	// $.omcAjax("/brow/chachCheck",{"type":"check"},function(data){
	// 	if(!data.success){
	// 		App.myConfirm(Msg.errorInfo.browCahcts,function(){
	// 			$.omcAjax("/brow/chachCheck",{"type":"save"},function(data){
	//
	// 			});
	// 		});
	// 	}
	// });
	if(Cookies.isGeMaxSize()){
		Cookies.clearOne();
	}
}
/**
 * 浏览器检测
 */
function broCheck(){
	var bbh = brower.getBbh();
	var bnm = brower.getName();
	if(bnm!="chrome"){
		var obw = Msg.errorInfo.otherBrow;
		var ts = Msg.errorInfo.downSuChrom;
   	 	$("#errTs").html(App.escapseHtml(ts));
   	 	$("#errTs").attr('language','Msg.errorInfo.downSuChrom');
		App.myConfirm(obw,function(){
			window.location.href = '/brow/down?fileName=browser/chrome.exe';
			App.myMsg(Msg.errorInfo.browDeclaration);
			$('#mywin').css('left','33.5%');
		});    		
	}else{
		$.omcAjax("/brow/browserInfo",{browser:bbh,"iscs":hacs},function(data){
			if(data){
				if(data.success){
				    return true;
		  		}else{
	  				var dcb = Msg.errorInfo.downChromeBrow;
	  				var ts = Msg.errorInfo.downSuChrom;
	  		    	$("#errTs").html(App.escapseHtml(ts));
	  		    	$("#errTs").attr('language','Msg.errorInfo.downSuChrom');
	    			App.myConfirm(dcb,function(){
	    				window.location.href = '/brow/down?fileName=browser/chrome.exe';
	    				App.myMsg(Msg.errorInfo.browDeclaration);
	    				$('#mywin').css('left','33.5%');
	    			});
		  		}
			}
  		});
	}
}

