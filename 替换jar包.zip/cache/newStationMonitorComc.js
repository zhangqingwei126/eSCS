var keyAlarmDataInterval;//关键告警数据定时器
var keyAlarmStationInterval;//关键告警电站定时器
var overTimeAlarmDataInterval;//超时未处理告警数据定时器
var overTimeAlarmStation;//超时未处理告警电站定时器
var historyAlarmDataInterval;//历史告警数据定时器
var historyAlarmType;//历史告警告警类型数据定时器

var buttonIdsArr = [];

var topoId;

/**
 * 初始化界面
 */
$(function() {
    var myhref = window.location.href;
    var all = myhref.split('?');
    if (all != null && all != undefined && all.length > 1) {
        var topo = all[1].split('&');
        if (topo != null && topo != undefined && topo.length > 0) {
            for (var k = 0; k < topo.length; k++) {
                var topo1 = topo[k].split('=');
                if ('topoid' == topo1[0]) {
                    topoId = topo1[1];
                }
            }
        }
	}
	checkRight(topoId);
	$("#index-top").show();
	$("#stationMonitor_title").show();
	$("#mainBody").show();
	var iscs = parent.Cookies.get('iscs') || parent.Cookies.getCook("iscs");
	if(!iscs || iscs!=="cs"){
		cacheCheck();
	}
});
function cacheCheck(){
	// $.omcAjax("/brow/chachCheck",{"type":"check"},function(data){
	// 	if(!data.success){
	// 		App.myConfirm(Msg.errorInfo.browCahcts,function(){
	// 			$.omcAjax("/brow/chachCheck",{"type":"save"},function(data){
	//
	// 			});
	// 		});
	// 	}
	// });
}
/**
 * 验证权限
 */
function checkRight(topoId) {
	$.omcAjax("/staff/auth",{},function(res){
		if(res.success) {
			var data = res.data;
			var sysMenu = data;
			sysMenu = App.getLevelRight(sysMenu);
			$("#comckeytimeAlarmMenu").hide();
			$("#comchistoryAlarmMenu").hide();
			$("#comchandleOverTimeAlarmMenu").hide();
			$("#comcstationStatus").hide();
			if(sysMenu && sysMenu.length >0){
				for(var i=0;i<sysMenu.length;i++){
					var buttonId = sysMenu[i];
					if(buttonId.level == 1){
						var auId = buttonId.id;
						if(auId == "comcstationStatus"|| auId == "comchistoryAlarmMenu"
							|| auId == "comckeytimeAlarmMenu" || auId == "comchandleOverTimeAlarmMenu"){
							buttonIdsArr.push(auId);
							$("#"+auId).show();
						}						
					}
				}
				$("#"+buttonIdsArr[0]).attr("class","xxgl-tab-click text");
				loadUrl(buttonIdsArr[0],topoId);
			}
		}
	});
}

/**
 * 定时器设置
 * @param timeout
 * @param id
 */
function setIntervalById(timeout,id) {
	if(id == "comckeytimeAlarmMenu") {// 关键告警
		closePush();
		keyAlarmDataInterval = window.setInterval(searchKeyAlarm,timeout);
		keyAlarmStationInterval = window.setInterval(loadKeyAlarmStationNum,timeout);
	}else if(id == "handleOverTimeAlarmMenu") {// 超时未处理告警
		closePush();
		overTimeAlarmDataInterval = window.setInterval(loadOvertimeAlarmData,timeout);
		overTimeAlarmStation = window.setInterval(getStationInfoByInput,timeout);
	}else if(id == "comchistoryAlarmMenu"){
		closePush();
		historyAlarmType = window.setInterval(getHiddenTypeAlarm,timeout);
		historyAlarmDataInterval = window.setInterval(loadAlarmData,timeout);
	}
	clearInvervalById(id);
}
/**
 * 清除定时器方法
 * @param id
 */
function clearInvervalById(id) {
	if(id == "comckeytimeAlarmMenu") {
		clearInterval(overTimeAlarmStation);
		clearInterval(overTimeAlarmDataInterval);
		clearInterval(historyAlarmType);
		clearInterval(historyAlarmDataInterval);
	}else if(id == "handleOverTimeAlarmMenu") {
		clearInterval(keyAlarmStationInterval);
		clearInterval(keyAlarmDataInterval);
		clearInterval(historyAlarmType);
		clearInterval(historyAlarmDataInterval);
	}else if(id == "comchistoryAlarmMenu") {
		clearInterval(keyAlarmStationInterval);
		clearInterval(keyAlarmDataInterval);
		clearInterval(overTimeAlarmStation);
		clearInterval(overTimeAlarmDataInterval);
	}else if(id == "stationStatus") {//电站状态
		clearInterval(keyAlarmStationInterval);
		clearInterval(keyAlarmDataInterval);
		clearInterval(overTimeAlarmStation);
		clearInterval(overTimeAlarmDataInterval);
		clearInterval(historyAlarmType);
		clearInterval(historyAlarmDataInterval);
	}
}

/**
 * 根据传入的id跳转到对应的界面
 * @param id
 */
function loadUrl(id,param) {
	var t = new Date().getTime();
	var url = omc[id].defPage.url;
	if(id == "comcstationStatus") {
		tabShow("","comcstationStatus","comchandleOverTimeAlarmMenu","comckeytimeAlarmMenu","comchistoryAlarmMenu");
	}else if(id == "comchandleOverTimeAlarmMenu") {
		tabShow("","comchandleOverTimeAlarmMenu","comcstationStatus","comckeytimeAlarmMenu","comchistoryAlarmMenu");
	}else if(id == "comchistoryAlarmMenu") {
		tabShow("","comchistoryAlarmMenu","comchandleOverTimeAlarmMenu","comcstationStatus","comckeytimeAlarmMenu");
	}else if(id == "keytimeAlarmMenu") {
		tabShow("","comckeytimeAlarmMenu","comchandleOverTimeAlarmMenu","comcstationStatus","comchistoryAlarmMenu");
	}else {
		tabShow("hide","comckeytimeAlarmMenu","comchandleOverTimeAlarmMenu","comcstationStatus","comchistoryAlarmMenu");
	}
	if(id == "comcstationStatus") {
		$(".rightList").hide();//暂时隐藏此处的按钮
	}else if(id == "keytimeAlarmMenu") {
	}else {
		$(".rightList").hide();
	}

	if(param){
        $("#loadDataDiv").load(url + "?t=" + t+"&topoId="+param);
	} else{
        $("#loadDataDiv").load(url + "?t=" + t);
	}
}

function tabShow(hide,showId,hideId1,hideId2,hideId3){
	if(hide == "") {
		$("#"+showId).attr("class","xxgl-tab-click text");
	}else {
		$("#"+showId).attr("class","xxgl-tab-unclick text");
	}
	$("#"+hideId1).attr("class","xxgl-tab-unclick text");
	$("#"+hideId2).attr("class","xxgl-tab-unclick text");
	$("#"+hideId3).attr("class","xxgl-tab-unclick text");
}

/**
 * 加载电站状态图表
 */
function loadPicList() {
	$("#stationStatusDataDiv").hide();
	loadUrl('stationStatus');
}
/**
 * 加载电站状态列表
 */
function loadNameList() {
	return false;
	$("#stationStatusDataDiv").show();
	var stationStatusDataDiv = $("#stationStatusDataDiv");
	$("#loadDataDiv").html('');
	$("#loadDataDiv").append(stationStatusDataDiv);
	loadStationStatusDataList();
}

var parm = {};
parm.pageIndex = 1;
parm.pageSize = 8;
parm.stationName = "";

/**
 * 加载电站状态的数据列表
 */
function loadStationStatusDataList() {
	
}
/** 取消订阅 */
function closePush() {
    parent.Webchannel.stopPush("allDevSignalSocketListener");
    parent.Webchannel.stopPush("StationStatusAutoGenerateSocketListener");
}
